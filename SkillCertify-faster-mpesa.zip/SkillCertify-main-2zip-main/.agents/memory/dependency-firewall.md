---
name: Dependency firewall compatibility
description: Explains the package choices required to install this project through Replit's security policy.
---

Keep the browser PDF packages on mutually compatible current releases, and do not re-add the legacy Paystack npm SDK unless the app actually adopts it and its dependency chain is safe.

**Why:** Older jsPDF resolution and the unused Paystack SDK pulled packages blocked by Replit's critical-CVE policy. The app already talks to Paystack through HTTP, so the SDK added risk without providing functionality.

**How to apply:** When changing payment or certificate dependencies, verify peer compatibility and installability through the package firewall before committing lockfile changes.