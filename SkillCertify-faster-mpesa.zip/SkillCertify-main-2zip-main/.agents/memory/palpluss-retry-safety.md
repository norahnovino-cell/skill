---
name: PalPluss retry safety
description: Defines the provider contract required before an M-Pesa initiation reservation may be released.
---

Only release a pending STK initiation reservation when PalPluss returns a documented error code with its documented HTTP status proving the request was not accepted. Treat generic 4xx responses, 2xx failure envelopes, 5xx responses, timeouts, malformed responses, and unknown transaction statuses as protected pending outcomes.

**Why:** HTTP status or a generic failure envelope alone does not prove that PalPluss did not accept or queue an STK prompt. Retrying an ambiguous outcome can produce a duplicate charge.

**How to apply:** Keep the provider-code/status allowlist synchronized with PalPluss documentation. Add a regression case for every new pair, and default any unrecognized response to reconciliation rather than retry.

Registration and payment-session acquisition must also be atomic at each stable identity boundary: normalized email to one temporary registration, authenticated user or registration token to one payment session. Preserve temporary registrations while a payment is pending or successful-but-not-finalized.

**Why:** Per-session payment uniqueness is insufficient if concurrent devices, token expiry, or the success-finalization window can create different sessions for the same purchase journey.

**How to apply:** Any registration, reload, or recovery flow must converge on the existing token and session before it can initiate STK. Only a confirmed failed payment may release that journey for cleanup and a new attempt.