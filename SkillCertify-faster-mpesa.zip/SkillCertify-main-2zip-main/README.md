# EnglishPro Test

English proficiency assessment with registration, PalPluss M-Pesa payment,
server-side scoring, results, and certificate delivery.

## Development

```bash
npm install
npm run dev
```

## Validation

```bash
npm test
npm run check
npm run build
```

## Deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for the Dokploy deployment guide.
