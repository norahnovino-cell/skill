# EnglishPro Test — Dokploy Deployment Guide

This application is ready to deploy from its root `Dockerfile`. It runs as one
Node.js service, serves the React frontend and Express API on the same port, and
uses PostgreSQL for all persistent data.

## Architecture

- **Application:** Node.js 20, Express, React/Vite
- **Container port:** `5000`
- **Health endpoint:** `GET /health`
- **Database:** PostgreSQL 16
- **Payment provider:** PalPluss M-Pesa STK Push
- **Persistent files:** none; all application data is stored in PostgreSQL

## 1. Push the project to Git

Dokploy can deploy from GitHub, GitLab, Bitbucket, or another Git repository.
Commit this project and push the branch you want Dokploy to deploy.

```bash
git add .
git commit -m "Prepare EnglishPro for Dokploy"
git push origin main
```

Never commit an `.env` file or any API key.

## 2. Create PostgreSQL in Dokploy

1. Create or open a Dokploy project and environment.
2. Add a **PostgreSQL** database service.
3. Use PostgreSQL 16.
4. Give it a persistent volume.
5. Deploy the database.
6. Copy its **internal** PostgreSQL connection URL.

The URL should resemble:

```text
postgresql://USERNAME:PASSWORD@INTERNAL_DATABASE_HOST:5432/DATABASE_NAME
```

Use the internal hostname when the app and database are in the same Dokploy
project/network. Do not publish PostgreSQL port `5432` to the public internet.

## 3. Create the Dokploy application

1. Add an **Application** in the same project/environment.
2. Select your Git provider, repository, and deployment branch.
3. Set the build type to **Dockerfile**.
4. Use:

| Setting | Value |
| --- | --- |
| Build context | `.` |
| Dockerfile path | `Dockerfile` |
| Container port | `5000` |
| Health-check path | `/health` |
| Health-check success code | `200` |

The container already starts with:

```text
node dist/server/index.js
```

Do not override the command with `npm run dev`; the Vite development server is
not appropriate for production.

## 4. Add environment variables

Add these as Dokploy service-level environment variables:

```env
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://USERNAME:PASSWORD@INTERNAL_DATABASE_HOST:5432/DATABASE_NAME
PALPLUSS_API_KEY=your_palpluss_api_key
PALPLUSS_CALLBACK_URL=https://test.example.com/api/payments/palpluss/webhook
DB_POOL_MAX=10
```

### Variable reference

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | Yes | Internal PostgreSQL connection URL |
| `PALPLUSS_API_KEY` | Yes | Server-side PalPluss credential |
| `PALPLUSS_CALLBACK_URL` | Yes for payments | Public HTTPS PalPluss webhook URL |
| `NODE_ENV` | Yes | Must be `production` |
| `PORT` | Yes | Keep as `5000` unless Dokploy is configured for another port |
| `DB_POOL_MAX` | No | Maximum PostgreSQL pool size; defaults to `10` |

Do not create any `VITE_*` payment variable. The PalPluss key is server-only and
must never be included in the browser bundle.

## 5. Configure the domain and HTTPS

1. In Dokploy, add the domain for the application.
2. Route the domain to container port `5000`.
3. Enable HTTPS/Let's Encrypt.
4. At your DNS provider, create an `A` record pointing the domain to the public
   IP address of the Dokploy server.
5. Wait until `https://YOUR_DOMAIN/health` returns `OK`.
6. Set `PALPLUSS_CALLBACK_URL` to:

```text
https://YOUR_DOMAIN/api/payments/palpluss/webhook
```

7. Redeploy after saving the final callback URL.

The callback must be public HTTPS. Do not use a Replit development URL,
`localhost`, an IP-only HTTP URL, or Dokploy's internal service hostname.

## 6. Deploy and initialize the database

Click **Deploy** and watch the build/runtime logs.

On startup, the server applies idempotent schema initialization and additive
migrations before accepting traffic. A new PostgreSQL database therefore does
not require a manual `drizzle-kit push` inside the production container.

Successful startup logs include:

```text
Database URL present: true
PalPluss configured: true
Server running on port 5000
```

Then verify:

```bash
curl -fsS https://YOUR_DOMAIN/health
```

Expected response:

```text
OK
```

## 7. Optional: migrate existing PostgreSQL data

Skip this section if the Dokploy deployment should start with an empty database.

Before importing, stop the Dokploy application so it cannot write during the
restore. Export the existing database from a trusted machine:

```bash
pg_dump --format=custom --no-owner --no-acl "$SOURCE_DATABASE_URL" \
  --file=englishpro.dump
```

Restore into the Dokploy database:

```bash
pg_restore --clean --if-exists --no-owner --no-acl \
  --dbname="$DOKPLOY_DATABASE_URL" englishpro.dump
```

Start/redeploy the application after the restore. Keep the dump private because
it contains candidate and payment records.

## 8. Production verification

### Non-charging checks

1. Open the landing page.
2. Confirm `GET /health` returns `200`.
3. Register a candidate with valid details.
4. Confirm an unpaid session cannot open the assessment.
5. Check the application logs for database or PalPluss configuration errors.

### Controlled live M-Pesa check

Only with explicit approval from the phone owner:

1. Register with that Kenyan M-Pesa number.
2. Initiate one KES 1,000 STK Push.
3. Confirm exactly one prompt arrives.
4. Complete the payment.
5. Confirm the account is created and the assessment unlocks.
6. Complete the assessment and verify results/certificate behavior.

Do not repeat this step automatically; it causes a real charge.

## 9. Backups and operations

- Enable scheduled PostgreSQL backups in Dokploy before accepting candidates.
- Store backups outside the Dokploy server when possible.
- Keep the database private on Dokploy's internal network.
- Start with one application replica. If replicas are increased later, keep all
  state in PostgreSQL and monitor database pool usage.
- Monitor both application and database logs.
- Redeploy after changing environment variables.
- Rotate `PALPLUSS_API_KEY` immediately if it is ever exposed.

## Troubleshooting

### Application exits during startup

- Confirm `DATABASE_URL` uses the database's internal hostname.
- Confirm the PostgreSQL service is running and reachable from the app.
- Check that the database user can create/alter tables and indexes.

### Health check fails

- Confirm Dokploy routes to port `5000`.
- Confirm `PORT=5000`.
- Check the runtime logs for database startup errors.
- Test `/health`, not only `/`.

### M-Pesa prompt does not start

- Confirm `PALPLUSS_API_KEY` is set on the application service.
- Confirm `PALPLUSS_CALLBACK_URL` is the final public HTTPS URL.
- Confirm the registered phone and submitted payment phone are the same.
- Review the app logs without printing the API key.

### Webhook is not received

- Confirm the domain is public and HTTPS works.
- Confirm the callback path is exactly
  `/api/payments/palpluss/webhook`.
- Confirm no proxy authentication or IP allowlist blocks PalPluss.
- Test the health URL externally before retrying a payment.

## Dokploy references

- Applications: <https://docs.dokploy.com/docs/core/applications>
- Environment variables: <https://docs.dokploy.com/docs/core/variables>
- Going to production: <https://docs.dokploy.com/docs/core/applications/going-production>
- Zero-downtime deployment: <https://docs.dokploy.com/docs/core/applications/zero-downtime>