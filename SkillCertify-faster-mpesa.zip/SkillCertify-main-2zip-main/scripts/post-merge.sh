#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

echo "Installing dependencies..."
npm install --no-audit --no-fund --prefer-offline

echo "Applying database schema..."
npm run db:push

echo "Running typecheck..."
npm run check

echo "Building production bundles..."
npm run build

echo "Post-merge setup completed."