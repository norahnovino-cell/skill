import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { sql } from "drizzle-orm";

const statements = [
  `CREATE TABLE IF NOT EXISTS "users" (
    "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    "first_name" text NOT NULL,
    "last_name" text NOT NULL,
    "email" text NOT NULL UNIQUE,
    "phone" text NOT NULL,
    "password" text NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "test_sessions" (
    "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    "user_id" varchar REFERENCES "users"("id"),
    "status" text DEFAULT 'pending' NOT NULL,
    "started_at" timestamp,
    "completed_at" timestamp,
    "total_score" integer,
    "reading_score" integer,
    "listening_score" integer,
    "writing_score" integer,
    "speaking_score" integer,
    "certificate_id" text,
    "payment_id" text,
    "payment_status" text DEFAULT 'pending' NOT NULL,
    "passed" boolean DEFAULT false NOT NULL,
    "result_details" jsonb,
    "certificate_issued_at" timestamp,
    "session_token" text,
    "session_token_expires_at" timestamp,
    "registration_token" text,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "test_answers" (
    "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    "session_id" varchar NOT NULL REFERENCES "test_sessions"("id"),
    "section" text NOT NULL,
    "question_id" text NOT NULL,
    "answer" jsonb,
    "is_correct" boolean,
    "score" integer,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "payments" (
    "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    "session_id" varchar NOT NULL REFERENCES "test_sessions"("id"),
    "paystack_reference" text NOT NULL,
    "amount" integer NOT NULL,
    "currency" text DEFAULT 'KES' NOT NULL,
    "provider" text DEFAULT 'palpluss' NOT NULL,
    "metadata" jsonb,
    "status" text DEFAULT 'pending' NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "user_sessions" (
    "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    "user_id" varchar NOT NULL REFERENCES "users"("id"),
    "token" text NOT NULL UNIQUE,
    "type" text NOT NULL,
    "expires_at" timestamp NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "temp_registrations" (
    "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    "token" text NOT NULL UNIQUE,
    "first_name" text NOT NULL,
    "last_name" text NOT NULL,
    "email" text NOT NULL,
    "phone" text NOT NULL,
    "password" text NOT NULL,
    "expires_at" timestamp NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `ALTER TABLE "test_sessions" ADD COLUMN IF NOT EXISTS "passed" boolean DEFAULT false NOT NULL`,
  `ALTER TABLE "test_sessions" ADD COLUMN IF NOT EXISTS "result_details" jsonb`,
  `ALTER TABLE "test_sessions" ADD COLUMN IF NOT EXISTS "certificate_issued_at" timestamp`,
  `ALTER TABLE "test_sessions" ADD COLUMN IF NOT EXISTS "session_token" text`,
  `ALTER TABLE "test_sessions" ADD COLUMN IF NOT EXISTS "session_token_expires_at" timestamp`,
  `ALTER TABLE "test_sessions" ADD COLUMN IF NOT EXISTS "registration_token" text`,
  `ALTER TABLE "payments" ADD COLUMN IF NOT EXISTS "currency" text DEFAULT 'KES' NOT NULL`,
  `ALTER TABLE "payments" ADD COLUMN IF NOT EXISTS "provider" text DEFAULT 'palpluss' NOT NULL`,
  `ALTER TABLE "payments" ADD COLUMN IF NOT EXISTS "metadata" jsonb`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "test_sessions_session_token_unique" ON "test_sessions" ("session_token")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "payments_paystack_reference_unique" ON "payments" ("paystack_reference")`,
  `DROP INDEX IF EXISTS "payments_one_pending_per_session"`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "test_answers_session_question_unique" ON "test_answers" ("session_id", "question_id")`,
];

export async function applyRuntimeMigrations(): Promise<void> {
  if (!process.env.DATABASE_URL) return;
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 2,
  });
  try {
    const database = drizzle(pool);
    for (const statement of statements) {
      await database.execute(sql.raw(statement));
    }
  } finally {
    await pool.end();
  }
}
