import crypto from "crypto";
import type { Express } from "express";
import { storage } from "./storage";

const PALPLUSS_BASE_URL = "https://api.palpluss.com/v1";
export const TEST_PRICE_KES = 1000;
const PAYMENT_CURRENCY = "KES";

/**
 * A local attempt_ reservation should normally exist only for a few seconds
 * while we wait for PalPluss to return the real transaction ID.
 *
 * If the app/container crashes during that tiny window, the reservation could
 * otherwise remain pending forever and prevent the customer from retrying.
 */
const STALE_LOCAL_ATTEMPT_MS = 90 * 1000;

export type PaymentContext = {
  sessionId: string;
  tempToken?: string;
  userId?: string;
  newRegistration: boolean;
};

export type PalPlussTransaction = {
  transactionId?: string;
  id?: string;
  status?: string;
  amount?: number;
  currency?: string;
  resultDescription?: string;
  result_desc?: string;
};

type PalPlussRequestError = Error & {
  status?: number;
  providerResponse?: boolean;
  explicitRejection?: boolean;
  providerCode?: string;
};

const paymentContexts = new Map<string, PaymentContext>();

/**
 * This protects against two requests hitting this specific Node process at
 * essentially the same moment.
 *
 * The database pending-payment constraint remains the durable protection.
 */
const activeTransactionBySession = new Map<string, string>();

const finalizationPromises = new Map<string, Promise<any>>();

const INITIATING_TRANSACTION = "initiating";

const ACTIVE_TRANSACTION_STATUSES = new Set([
  "PENDING",
  "PROCESSING",
]);

const FAILED_TRANSACTION_STATUSES = new Set([
  "FAILED",
  "CANCELLED",
  "EXPIRED",
  "REVERSED",
  "REJECTED",
  "DECLINED",
]);

const DEFINITIVE_INITIATION_REJECTIONS = new Map<string, number>([
  ["INVALID_API_KEY", 401],
  ["NO_PAYMENT_CHANNELS", 400],
  ["NO_DEFAULT_CHANNEL", 400],
  ["CHANNEL_NOT_FOUND", 400],
  ["INVALID_PHONE", 400],
  ["INSUFFICIENT_SERVICE_BALANCE", 402],
  ["STK_TEMP_BANNED", 429],
]);

function getApiKey(): string {
  const apiKey = process.env.PALPLUSS_API_KEY;

  validatePalPlussApiKey(apiKey);

  return apiKey!;
}

export function validatePalPlussApiKey(
  apiKey: string | undefined,
): void {
  if (
    typeof apiKey !== "string" ||
    !apiKey ||
    apiKey.trim() !== apiKey ||
    /[\r\n\t ]/.test(apiKey)
  ) {
    throw new Error(
      "PALPLUSS_API_KEY is missing or has an invalid format",
    );
  }
}

function getAuthorizationHeader(): string {
  return `Basic ${Buffer.from(`${getApiKey()}:`).toString("base64")}`;
}

function getCallbackUrl(): string {
  const callbackUrl =
    process.env.PALPLUSS_CALLBACK_URL ||
    (
      process.env.REPLIT_DEV_DOMAIN
        ? `https://${process.env.REPLIT_DEV_DOMAIN}/api/payments/palpluss/webhook`
        : ""
    );

  validatePalPlussCallbackUrl(callbackUrl);

  return callbackUrl;
}

export function validatePalPlussCallbackUrl(
  callbackUrl: string,
): void {
  let parsedUrl: URL;

  try {
    parsedUrl = new URL(callbackUrl);
  } catch {
    throw new Error(
      "PalPluss requires a trusted HTTPS callback URL. Set PALPLUSS_CALLBACK_URL.",
    );
  }

  if (
    parsedUrl.protocol !== "https:" ||
    !parsedUrl.hostname ||
    parsedUrl.username ||
    parsedUrl.password
  ) {
    throw new Error(
      "PalPluss requires a trusted HTTPS callback URL. Set PALPLUSS_CALLBACK_URL.",
    );
  }
}

export function validatePalPlussConfiguration(): void {
  getApiKey();
  getCallbackUrl();
}

async function getAuthenticatedUserId(
  authToken: string | undefined,
): Promise<string | null> {
  if (!authToken) {
    return null;
  }

  const authSession = await storage.getUserSession(authToken);

  if (
    !authSession ||
    authSession.type !== "auth" ||
    authSession.expiresAt < new Date()
  ) {
    return null;
  }

  return authSession.userId;
}

async function callPalPluss(
  path: string,
  init: RequestInit = {},
): Promise<any> {
  const response = await fetch(
    `${PALPLUSS_BASE_URL}${path}`,
    {
      ...init,
      headers: {
        Authorization: getAuthorizationHeader(),
        "Content-Type": "application/json",
        ...(init.headers || {}),
      },
    },
  );

  const payload = await response
    .json()
    .catch(() => null);

  if (!response.ok || !payload?.success) {
    const error = new Error(
      payload?.error?.message ||
      payload?.message ||
      `PalPluss request failed with status ${response.status}`,
    ) as PalPlussRequestError;

    error.status = response.status;
    error.providerResponse = true;

    error.providerCode =
      typeof payload?.error?.code === "string"
        ? payload.error.code
        : typeof payload?.code === "string"
          ? payload.code
          : undefined;

    error.explicitRejection =
      isDefinitivePalPlussRejection(
        response.status,
        error.providerCode,
      );

    throw error;
  }

  return payload.data;
}

export function isDefinitivePalPlussRejection(
  status: number,
  providerCode: string | undefined,
): boolean {
  return (
    typeof providerCode === "string" &&
    DEFINITIVE_INITIATION_REJECTIONS.get(providerCode) === status
  );
}

export function isExplicitProviderRejection(
  error: unknown,
): boolean {
  return Boolean(
    error &&
    typeof error === "object" &&
    (error as PalPlussRequestError).providerResponse === true &&
    (error as PalPlussRequestError).explicitRejection === true
  );
}

function getTransactionId(
  transaction: PalPlussTransaction,
): string | null {
  return (
    transaction.transactionId ||
    transaction.id ||
    null
  );
}

export function isSuccessfulTransaction(
  transaction: PalPlussTransaction,
): boolean {
  return (
    transaction.status === "SUCCESS" &&
    transaction.currency === PAYMENT_CURRENCY &&
    Number(transaction.amount) === TEST_PRICE_KES
  );
}

export function isActiveTransaction(
  transaction: PalPlussTransaction,
): boolean {
  return ACTIVE_TRANSACTION_STATUSES.has(
    transaction.status || "",
  );
}

export function isConfirmedFailedTransaction(
  transaction: PalPlussTransaction,
): boolean {
  return FAILED_TRANSACTION_STATUSES.has(
    transaction.status || "",
  );
}

export function isPaymentSessionPaid(
  paymentStatus: string,
  payments: Array<{ status: string }>,
): boolean {
  return (
    paymentStatus === "completed" ||
    payments.some(
      (payment) => payment.status === "success",
    )
  );
}

export function createPalPlussAccountReference(
  attemptReference: string,
): string {
  return attemptReference
    .replace(/^attempt_/, "EP")
    .replace(/[^A-Za-z0-9]/g, "")
    .slice(0, 12);
}

export function normalizePhone(
  phone: string,
): string {
  const digits = phone.replace(/\D/g, "");

  if (digits.startsWith("254")) {
    return digits.slice(3);
  }

  return digits.replace(/^0/, "");
}

export function isPaymentPhoneAuthorized(
  registeredPhone: string,
  submittedPhone: string,
): boolean {
  return (
    normalizePhone(registeredPhone) ===
    normalizePhone(submittedPhone)
  );
}

function contextFromPayment(
  payment: any,
): PaymentContext | null {
  const metadata = payment?.metadata;

  if (
    !metadata ||
    typeof metadata !== "object" ||
    typeof metadata.sessionId !== "string"
  ) {
    return null;
  }

  return {
    sessionId: metadata.sessionId,

    tempToken:
      typeof metadata.tempToken === "string"
        ? metadata.tempToken
        : undefined,

    userId:
      typeof metadata.userId === "string"
        ? metadata.userId
        : undefined,

    newRegistration:
      metadata.newRegistration === true,
  };
}

async function fetchTransaction(
  transactionId: string,
): Promise<PalPlussTransaction> {
  return callPalPluss(
    `/transactions/${encodeURIComponent(transactionId)}`,
  );
}

async function markProviderStatus(
  transactionId: string,
  transaction: PalPlussTransaction,
) {
  const payment =
    await storage.getPaymentByReference(transactionId);

  if (
    !payment ||
    payment.provider !== "palpluss" ||
    payment.amount !== TEST_PRICE_KES ||
    payment.currency !== PAYMENT_CURRENCY
  ) {
    return null;
  }

  if (isSuccessfulTransaction(transaction)) {
    if (payment.status !== "success") {
      await storage.updatePayment(
        payment.id,
        {
          status: "success",
        },
      );
    }

    const session =
      await storage.getTestSession(payment.sessionId);

    if (
      session &&
      session.paymentStatus !== "completed"
    ) {
      await storage.updateTestSession(
        session.id,
        {
          paymentStatus: "completed",
          status: "pending",
          paymentId: payment.id,
        },
      );
    }

    activeTransactionBySession.delete(
      payment.sessionId,
    );
  } else if (
    isConfirmedFailedTransaction(transaction)
  ) {
    if (payment.status !== "success") {
      await storage.updatePayment(
        payment.id,
        {
          status: "failed",
        },
      );
    }

    activeTransactionBySession.delete(
      payment.sessionId,
    );
  }

  return payment;
}

/**
 * Checks an old pending payment before deciding whether another STK prompt can
 * be created.
 *
 * return:
 *   "released" = old attempt is dead and the new payment may continue
 *   "active"   = old STK is still active; do not create another
 *   "success"  = old payment succeeded; never create another
 *   "unknown"  = provider state cannot safely be determined
 */
async function reconcilePendingPayment(
  sessionId: string,
  pendingPayment: any,
): Promise<
  "released" |
  "active" |
  "success" |
  "unknown"
> {
  const reference =
    pendingPayment.paystackReference;

  /**
   * "attempt_" means the database reservation was created but PalPluss had not
   * yet supplied a real transaction ID.
   */
  if (reference.startsWith("attempt_")) {
    const createdAt =
      pendingPayment.createdAt
        ? new Date(pendingPayment.createdAt)
        : null;

    const attemptAge =
      createdAt
        ? Date.now() - createdAt.getTime()
        : 0;

    if (
      createdAt &&
      attemptAge >= STALE_LOCAL_ATTEMPT_MS
    ) {
      console.warn(
        `Releasing stale local payment attempt ${reference} for session ${sessionId}`,
      );

      await storage.updatePayment(
        pendingPayment.id,
        {
          status: "failed",
        },
      );

      activeTransactionBySession.delete(
        sessionId,
      );

      return "released";
    }

    return "unknown";
  }

  try {
    const transaction =
      await fetchTransaction(reference);

    if (isSuccessfulTransaction(transaction)) {
      await markProviderStatus(
        reference,
        transaction,
      );

      return "success";
    }

    if (isConfirmedFailedTransaction(transaction)) {
      await markProviderStatus(
        reference,
        transaction,
      );

      return "released";
    }

    if (isActiveTransaction(transaction)) {
      activeTransactionBySession.set(
        sessionId,
        reference,
      );

      return "active";
    }

    /**
     * PalPluss returned a state we do not recognise as final.
     * Do not blindly send another STK push because the previous transaction
     * might still complete.
     */
    return "unknown";
  } catch (error) {
    console.error(
      "Unable to reconcile existing PalPluss payment:",
      error instanceof Error
        ? error.message
        : error,
    );

    return "unknown";
  }
}

async function finalizeSuccessfulPayment(
  transactionId: string,
  context: PaymentContext,
) {
  const payment =
    await storage.getPaymentByReference(transactionId);

  if (
    !payment ||
    payment.status !== "success"
  ) {
    throw new Error(
      "Verified payment record not found",
    );
  }

  let session =
    await storage.getTestSession(context.sessionId);

  if (
    !session ||
    session.id !== payment.sessionId
  ) {
    throw new Error(
      "Test session not found",
    );
  }

  let userId =
    context.userId ||
    session.userId;

  if (!userId) {
    if (!context.tempToken) {
      throw new Error(
        "Registration token is required",
      );
    }

    const tempRegistration =
      await storage.getTempRegistration(
        context.tempToken,
      );

    if (
      !tempRegistration ||
      tempRegistration.expiresAt < new Date()
    ) {
      throw new Error(
        "Registration expired. Please register again.",
      );
    }

    const existingUser =
      await storage.getUserByEmail(
        tempRegistration.email,
      );

    let user = existingUser;

    if (!user) {
      try {
        user = await storage.createUser({
          firstName:
            tempRegistration.firstName,

          lastName:
            tempRegistration.lastName,

          email:
            tempRegistration.email,

          phone:
            tempRegistration.phone,

          password:
            tempRegistration.password,
        });
      } catch (error) {
        user =
          await storage.getUserByEmail(
            tempRegistration.email,
          );

        if (!user) {
          throw error;
        }
      }
    }

    userId = user.id;
    context.userId = user.id;

    paymentContexts.set(
      transactionId,
      context,
    );

    await storage.updatePayment(
      payment.id,
      {
        metadata: {
          ...context,
          sessionId: context.sessionId,
        },
      },
    );

    await storage.deleteTempRegistration(
      context.tempToken,
    );
  }

  session =
    (
      await storage.updateTestSession(
        session.id,
        {
          userId,
          paymentStatus: "completed",
          paymentId: payment.id,
          status: "pending",
        },
      )
    ) || session;

  if (!context.newRegistration) {
    return {
      success: true,
      session,
    };
  }

  const user =
    await storage.getUser(userId);

  if (!user) {
    throw new Error(
      "User account not found after payment",
    );
  }

  const existingAuth =
    await storage.getUserSessionByUser(
      userId,
      "auth",
    );

  const hasUsableAuth = Boolean(
    existingAuth &&
    existingAuth.expiresAt > new Date(),
  );

  const authToken =
    hasUsableAuth
      ? existingAuth!.token
      : crypto
          .randomBytes(32)
          .toString("base64url");

  if (!hasUsableAuth) {
    await storage.createUserSession({
      userId,
      token: authToken,
      type: "auth",
      expiresAt:
        new Date(
          Date.now() +
          24 * 60 * 60 * 1000,
        ),
    });
  }

  const {
    password: _password,
    ...safeUser
  } = user;

  return {
    success: true,
    user: safeUser,
    authToken,
    session,
  };
}

export function runFinalizationOnce<T>(
  reference: string,
  worker: () => Promise<T>,
): Promise<T> {
  const existing =
    finalizationPromises.get(reference);

  if (existing) {
    return existing;
  }

  const operation = worker();

  finalizationPromises.set(
    reference,
    operation,
  );

  operation.then(
    () =>
      finalizationPromises.delete(
        reference,
      ),
    () =>
      finalizationPromises.delete(
        reference,
      ),
  );

  return operation;
}

function finalizeOnce(
  transactionId: string,
  context: PaymentContext,
) {
  return runFinalizationOnce(
    transactionId,
    () =>
      finalizeSuccessfulPayment(
        transactionId,
        context,
      ),
  );
}

export function registerPalPlussRoutes(
  app: Express,
  validatePaymentSessionToken: (
    sessionId: string,
    sessionToken: string,
    tempToken?: string,
  ) => Promise<boolean>,
) {
  /**
   * ------------------------------------------------------------
   * CREATE / RETRY M-PESA STK PUSH
   * ------------------------------------------------------------
   */
  app.post(
    "/api/payments/palpluss/stk",
    async (req, res) => {
      let payment: any;
      let context: PaymentContext | undefined;
      const startedAt = Date.now();

      try {
        const {
          phone,
          sessionId,
          tempToken,
        } = req.body;

        if (
          typeof phone !== "string" ||
          typeof sessionId !== "string"
        ) {
          return res.status(400).json({
            success: false,
            message: "Phone number and test session are required",
          });
        }

        const sessionToken = req.headers["x-session-token"] as string | undefined;

        if (!sessionToken) {
          return res.status(401).json({
            success: false,
            message: "Invalid payment session. Please start again.",
          });
        }

        // SPEED: run every independent lookup in ONE parallel batch instead of
        // ~8 sequential database round trips. The session is fetched once and
        // validated inline (previously it was fetched three times).
        const [
          session,
          sessionPayments,
          authenticatedUserId,
          prefetchedTempRegistration,
        ] = await Promise.all([
          storage.getTestSession(sessionId),
          storage.getPaymentsBySession(sessionId),
          getAuthenticatedUserId(
            req.headers["x-auth-token"] as string | undefined,
          ),
          typeof tempToken === "string" && tempToken
            ? storage.getTempRegistration(tempToken)
            : Promise.resolve(null),
        ]);

        if (!session) {
          return res.status(400).json({
            success: false,
            message: "This test session cannot accept a payment",
          });
        }

        const sessionTokenValid = Boolean(
          session.sessionToken === sessionToken &&
          session.sessionTokenExpiresAt &&
          session.sessionTokenExpiresAt > new Date() &&
          (tempToken
            ? session.registrationToken === tempToken
            : !session.registrationToken),
        );

        if (!sessionTokenValid) {
          return res.status(401).json({
            success: false,
            message: "Invalid payment session. Please start again.",
          });
        }

        // The only hard stop is a payment we already know succeeded.
        // Older PENDING attempts are intentionally ignored so the user can
        // request another STK prompt immediately.
        if (isPaymentSessionPaid(session.paymentStatus, sessionPayments)) {
          return res.status(400).json({
            success: false,
            status: "success",
            retryable: false,
            protected: true,
            message: "This test session has already been paid for.",
          });
        }

        if (authenticatedUserId) {
          const user = await storage.getUser(authenticatedUserId);

          if (
            session.userId !== authenticatedUserId ||
            !user ||
            !isPaymentPhoneAuthorized(user.phone, phone)
          ) {
            return res.status(403).json({
              success: false,
              message: "Use the phone number registered to this account",
            });
          }

          context = {
            sessionId,
            userId: authenticatedUserId,
            newRegistration: false,
          };
        } else {
          const tempRegistration = prefetchedTempRegistration;

          if (
            !tempRegistration ||
            tempRegistration.expiresAt < new Date() ||
            session.userId ||
            !isPaymentPhoneAuthorized(tempRegistration.phone, phone)
          ) {
            return res.status(401).json({
              success: false,
              message: "Registration expired or phone number does not match",
            });
          }

          context = {
            sessionId,
            tempToken,
            newRegistration: true,
          };
        }

        validatePalPlussConfiguration();

        // Every valid click gets a brand-new local payment attempt.
        // Multiple pending attempts for the same session are allowed.
        const attemptReference = `attempt_${crypto.randomUUID()}`;

        payment = await storage.createPayment({
          sessionId,
          paystackReference: attemptReference,
          amount: TEST_PRICE_KES,
          currency: PAYMENT_CURRENCY,
          provider: "palpluss",
          metadata: context,
          status: "pending",
        });

        const dbReadyAt = Date.now();

        // SPEED: the session's paymentId pointer is not needed to send the STK,
        // so update it in parallel with the PalPluss call instead of before it.
        // It is non-fatal: markProviderStatus() sets paymentId again on success.
        const linkSessionPromise = storage
          .updateTestSession(sessionId, { paymentId: payment.id })
          .catch((linkError) => {
            console.error(
              "Unable to link payment to test session:",
              linkError instanceof Error ? linkError.message : linkError,
            );
          });

        // Send the STK request immediately. There is no artificial wait and no
        // reconciliation gate for older pending attempts.
        const transaction = await callPalPluss(
          "/payments/stk",
          {
            method: "POST",
            body: JSON.stringify({
              amount: TEST_PRICE_KES,
              phone,
              accountReference: createPalPlussAccountReference(attemptReference),
              transactionDesc: "English Test",
              callbackUrl: getCallbackUrl(),
            }),
          },
        ) as PalPlussTransaction;

        const providerDoneAt = Date.now();
        console.log(
          `[STK timing] session=${sessionId} db_prep=${dbReadyAt - startedAt}ms palpluss_api=${providerDoneAt - dbReadyAt}ms`,
        );

        await linkSessionPromise;

        const transactionId = getTransactionId(transaction);

        if (!transactionId) {
          throw new Error("PalPluss did not return a transaction ID");
        }

        await storage.updatePayment(payment.id, {
          paystackReference: transactionId,
          metadata: context,
        });

        paymentContexts.set(transactionId, context);

        return res.json({
          success: true,
          transactionId,
          status: transaction.status || "PENDING",
          message: "STK Push sent. Check your phone and enter your M-Pesa PIN.",
        });
      } catch (error) {
        // In this permissive retry mode we deliberately release the local
        // attempt on ANY initiation error. This means the next click can send a
        // fresh STK even when the previous provider outcome is uncertain.
        // The tradeoff is that a rare delayed provider success can result in
        // more than one completed payment, which the business has accepted.
        if (payment) {
          try {
            await storage.updatePayment(payment.id, {
              status: "failed",
            });
          } catch (releaseError) {
            console.error(
              "Unable to release failed PalPluss attempt:",
              releaseError instanceof Error
                ? releaseError.message
                : releaseError,
            );
          }
        }

        console.error(
          "PalPluss STK Push error:",
          error instanceof Error ? error.message : error,
        );

        return res.status((error as any)?.status || 500).json({
          success: false,
          status: "failed",
          protected: false,
          retryable: true,
          message:
            error instanceof Error
              ? `${error.message}. You can try again immediately.`
              : "Unable to start M-Pesa payment. You can try again immediately.",
        });
      }
    },
  );

  /**
   * ------------------------------------------------------------
   * CHECK PAYMENT STATUS
   * ------------------------------------------------------------
   */
  app.post(
    "/api/payments/palpluss/status",
    async (req, res) => {
      try {
        const {
          transactionId,
          tempToken,
        } = req.body;

        if (
          typeof transactionId !==
          "string"
        ) {
          return res
            .status(400)
            .json({
              success: false,
              message:
                "Transaction ID is required",
            });
        }

        const payment =
          await storage.getPaymentByReference(
            transactionId,
          );

        const context =
          paymentContexts.get(
            transactionId,
          ) ||
          contextFromPayment(
            payment,
          );

        if (
          !payment ||
          !context
        ) {
          return res
            .status(404)
            .json({
              success: false,
              message:
                "Payment session not found. Please try again.",
            });
        }

        const sessionToken =
          req.headers[
            "x-session-token"
          ] as string | undefined;

        const authenticatedUserId =
          await getAuthenticatedUserId(
            req.headers[
              "x-auth-token"
            ] as string | undefined,
          );

        const ownsSession =
          Boolean(
            sessionToken &&
            await validatePaymentSessionToken(
              context.sessionId,
              sessionToken,
              context.tempToken,
            ),
          );

        const authorized =
          ownsSession &&
          (
            context.newRegistration
              ? Boolean(
                  tempToken &&
                  tempToken ===
                    context.tempToken,
                )
              : authenticatedUserId ===
                context.userId
          );

        if (!authorized) {
          return res
            .status(401)
            .json({
              success: false,
              message:
                "You are not authorized to check this payment",
            });
        }

        const transaction =
          await fetchTransaction(
            transactionId,
          );

        await markProviderStatus(
          transactionId,
          transaction,
        );

        /**
         * SUCCESS
         */
        if (
          isSuccessfulTransaction(
            transaction,
          )
        ) {
          return res.json(
            await finalizeOnce(
              transactionId,
              context,
            ),
          );
        }

        /**
         * STILL ACTIVE
         */
        if (
          isActiveTransaction(
            transaction,
          )
        ) {
          return res.json({
            success: false,
            status: "pending",
            protected: true,
            retryable: false,
            message:
              "Waiting for M-Pesa confirmation",
          });
        }

        /**
         * CANCELLED / FAILED / EXPIRED / DECLINED / REJECTED
         *
         * markProviderStatus() has already changed the DB payment from pending
         * to failed, so the user can immediately request another STK.
         */
        if (
          isConfirmedFailedTransaction(
            transaction,
          )
        ) {
          activeTransactionBySession.delete(
            context.sessionId,
          );

          return res.json({
            success: false,
            status: "failed",
            retryable: true,
            protected: false,
            message:
              transaction.resultDescription ||
              transaction.result_desc ||
              "M-Pesa payment was not completed. You can try again.",
          });
        }

        /**
         * Unknown states remain protected because we cannot yet prove that the
         * provider will not complete the payment later.
         */
        return res.json({
          success: false,
          status: "pending",
          retryable: false,
          protected: true,
          message:
            "The M-Pesa outcome is still being verified. Please try again shortly.",
        });
      } catch (error) {
        console.error(
          "PalPluss status error:",
          error instanceof Error
            ? error.message
            : error,
        );

        return res
          .status(
            (error as any)?.status ||
            500,
          )
          .json({
            success: false,
            status: "pending",
            protected: true,
            retryable: false,
            message:
              error instanceof Error
                ? error.message
                : "Unable to verify M-Pesa payment",
          });
      }
    },
  );

  /**
   * ------------------------------------------------------------
   * PALPLUSS WEBHOOK
   * ------------------------------------------------------------
   */
  app.post(
    "/api/payments/palpluss/webhook",
    async (req, res) => {
      const transactionId =
        req.body?.transaction?.id;

      if (
        typeof transactionId !==
        "string"
      ) {
        return res
          .status(200)
          .json({
            received: true,
          });
      }

      try {
        const payment =
          await storage.getPaymentByReference(
            transactionId,
          );

        if (!payment) {
          return res
            .status(200)
            .json({
              received: true,
            });
        }

        /**
         * Do not trust the webhook payload alone.
         * Fetch the transaction directly from PalPluss.
         */
        const transaction =
          await fetchTransaction(
            transactionId,
          );

        await markProviderStatus(
          transactionId,
          transaction,
        );

        const context =
          paymentContexts.get(
            transactionId,
          ) ||
          contextFromPayment(
            payment,
          );

        if (
          context &&
          isSuccessfulTransaction(
            transaction,
          )
        ) {
          await finalizeOnce(
            transactionId,
            context,
          );
        }

        return res
          .status(200)
          .json({
            received: true,
          });
      } catch (error) {
        console.error(
          "PalPluss webhook verification error:",
          error instanceof Error
            ? error.message
            : error,
        );

        return res
          .status(500)
          .json({
            received: false,
          });
      }
    },
  );
}
