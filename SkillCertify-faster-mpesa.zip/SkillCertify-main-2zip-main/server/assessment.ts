import type { TestAnswer } from "@shared/schema";

export const ASSESSMENT_VERSION = "professional-english-v1";
export const PASS_THRESHOLD = 70;
export const MIN_SECTION_SCORE = 60;

export const SECTION_REQUIREMENTS = {
  reading: {
    questionIds: [
      "reading_1", "reading_2", "reading_3", "reading_4", "reading_5",
      "reading_6", "reading_7", "reading_8", "reading_9", "reading_10",
      "reading_11", "reading_12", "reading_13", "reading_14", "reading_15",
    ],
  },
  listening: {
    questionIds: [
      "listening_1", "listening_2", "listening_3", "listening_4", "listening_5",
      "listening_6", "listening_7", "listening_8", "listening_9", "listening_10",
    ],
  },
  writing: {
    questionIds: ["writing_1", "writing_2"],
    minimumWords: { writing_1: 150, writing_2: 250 },
  },
  speaking: {
    questionIds: ["speaking_1", "speaking_2"],
    minimumAudioBytes: 20_000,
  },
} as const;

export type AssessmentSection = keyof typeof SECTION_REQUIREMENTS;

const answerKey: Record<string, string | string[]> = {
  reading_1: "b",
  reading_2: "b",
  reading_3: "true",
  reading_4: "intermittent",
  reading_5: "b",
  reading_6: "c",
  reading_7: "false",
  reading_8: ["surgery simulations", "ancient civilizations"],
  reading_9: "b",
  reading_10: ["energy-storage", "ai-learning", "vr-surgery", "grid-infrastructure"],
  reading_11: "b",
  reading_12: "true",
  reading_13: "human connection",
  reading_14: ["denmark", "germany"],
  reading_15: "b",
  listening_1: "b",
  listening_2: "b",
  listening_3: "a",
  listening_4: "250",
  listening_5: "5",
  listening_6: ["ai integration", "voice control"],
  listening_7: "a",
  listening_8: "12",
  listening_9: "d",
  listening_10: ["multilingual workforce", "tech hubs"],
};

const allQuestionSections = new Map<string, AssessmentSection>(
  Object.entries(SECTION_REQUIREMENTS).flatMap(([section, definition]) =>
    definition.questionIds.map((questionId) => [questionId, section as AssessmentSection]),
  ),
);

function normalize(value: unknown): string {
  return String(value ?? "")
    .toLowerCase()
    .replace(/[’']/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function words(value: string): string[] {
  return value.trim() ? value.trim().split(/\s+/).filter(Boolean) : [];
}

export function wordCount(value: unknown): number {
  return words(String(value ?? "")).length;
}

function isStructuredAnswer(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function decodedAudioBytes(value: unknown): number {
  if (!isStructuredAnswer(value)) return 0;
  const audioData = value.audioData;
  if (typeof audioData !== "string" || !/^data:audio\/[a-z0-9.+-]+;base64,/i.test(audioData)) return 0;
  const encoded = audioData.slice(audioData.indexOf(",") + 1);
  if (!/^[a-z0-9+/]*={0,2}$/i.test(encoded)) return 0;
  try {
    return Buffer.from(encoded, "base64").byteLength;
  } catch {
    return 0;
  }
}

function isValidAudioAnswer(value: unknown): boolean {
  if (!isStructuredAnswer(value)) return false;
  const durationSeconds = Number(value.durationSeconds);
  const actualBytes = decodedAudioBytes(value);
  return actualBytes >= SECTION_REQUIREMENTS.speaking.minimumAudioBytes &&
    actualBytes <= 10_000_000 &&
    value.verifiedAudio === true &&
    Number.isFinite(durationSeconds) &&
    durationSeconds >= 45 &&
    durationSeconds <= 180;
}

function answerIsPresent(answer: TestAnswer): boolean {
  if (answer.section === "speaking") return isValidAudioAnswer(answer.answer);
  if (answer.section === "writing") return wordCount(answer.answer) > 0;
  return normalize(answer.answer) !== "";
}

export type AssessmentValidation = {
  valid: boolean;
  missing: string[];
  invalid: string[];
  wordCounts: Record<string, number>;
};

export function validateAssessmentAnswers(answers: TestAnswer[]): AssessmentValidation {
  const byQuestion = new Map(answers.map((answer) => [answer.questionId, answer]));
  const missing: string[] = [];
  const invalid: string[] = [];
  const wordCounts: Record<string, number> = {};

  for (const [questionId, section] of Array.from(allQuestionSections.entries())) {
    const answer = byQuestion.get(questionId);
    if (!answer || answer.section !== section || !answerIsPresent(answer)) {
      missing.push(questionId);
      continue;
    }
    if (section === "writing") {
      const count = wordCount(answer.answer);
      wordCounts[questionId] = count;
      const minimum = SECTION_REQUIREMENTS.writing.minimumWords[
        questionId as keyof typeof SECTION_REQUIREMENTS.writing.minimumWords
      ];
      if (count < minimum) invalid.push(`${questionId}: minimum ${minimum} words`);
    }
  }

  return { valid: missing.length === 0 && invalid.length === 0, missing, invalid, wordCounts };
}

function normalizedParts(value: unknown): string[] {
  return normalize(value)
    .split(/[,\n;]+/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function matchesExpected(value: unknown, expected: string | string[]): boolean {
  const actual = normalize(value);
  if (!actual) return false;
  if (Array.isArray(expected)) {
    const parts = normalizedParts(value);
    return expected.every((item) => {
      const target = normalize(item);
      return actual.includes(target) || parts.includes(target);
    });
  }
  return actual === normalize(expected);
}

const writingSignals: Record<string, string[]> = {
  writing_1: ["executive", "summary", "recommendation", "benefit", "cost", "employee", "wellness", "implement", "program"],
  writing_2: ["agree", "disagree", "example", "advantage", "benefit", "disadvantage", "problem", "conclusion", "society", "communication"],
};

function scoreWriting(questionId: string, value: unknown): number {
  const rawText = String(value ?? "");
  const text = normalize(rawText);
  const count = wordCount(text);
  const minimum = SECTION_REQUIREMENTS.writing.minimumWords[
    questionId as keyof typeof SECTION_REQUIREMENTS.writing.minimumWords
  ];
  if (count < minimum) return 0;

  const lengthScore = Math.min(35, 25 + Math.floor((count - minimum) / 25));
  const paragraphs = rawText.split(/\n\s*\n/).filter((paragraph) => paragraph.trim()).length;
  const structureScore = paragraphs >= 3 ? 20 : paragraphs >= 2 ? 14 : 7;
  const signals = writingSignals[questionId] ?? [];
  const signalScore = Math.min(30, signals.filter((signal) => text.includes(signal)).length * 5);
  const uniqueWords = new Set(words(text)).size;
  const vocabularyScore = Math.min(15, Math.floor(uniqueWords / Math.max(1, count) * 100));
  return Math.min(100, lengthScore + structureScore + signalScore + vocabularyScore);
}

function scoreSpeaking(value: unknown): number {
  if (!isValidAudioAnswer(value)) return 0;
  const size = decodedAudioBytes(value);
  return Math.min(100, 60 + Math.min(40, Math.floor(size / 10_000)));
}

export type AssessmentScore = {
  total: number;
  reading: number;
  listening: number;
  writing: number;
  speaking: number;
  passed: boolean;
  cefr: string;
  proficiency: string;
  feedback: string[];
  answerResults: Array<{ questionId: string; section: AssessmentSection; isCorrect: boolean; score: number }>;
};

function cefrFor(score: number): string {
  if (score >= 85) return "C2";
  if (score >= 75) return "C1";
  if (score >= 65) return "B2";
  if (score >= 55) return "B1";
  if (score >= 45) return "A2";
  return "A1";
}

function proficiencyFor(score: number): string {
  if (score >= 85) return "Mastery";
  if (score >= 75) return "Advanced";
  if (score >= 65) return "Upper-intermediate";
  if (score >= 55) return "Intermediate";
  if (score >= 45) return "Elementary";
  return "Beginner";
}

export function scoreAssessment(answers: TestAnswer[]): AssessmentScore {
  const answerResults: AssessmentScore["answerResults"] = [];
  const objectiveScores = { reading: 0, listening: 0 };
  const objectiveCounts = { reading: 0, listening: 0 };
  let writingTotal = 0;
  let speakingTotal = 0;
  let writingCount = 0;
  let speakingCount = 0;

  for (const answer of answers) {
    const section = answer.section as AssessmentSection;
    if (!allQuestionSections.has(answer.questionId) || allQuestionSections.get(answer.questionId) !== section) continue;

    if (section === "reading" || section === "listening") {
      const expected = answerKey[answer.questionId];
      const isCorrect = expected !== undefined && matchesExpected(answer.answer, expected);
      objectiveCounts[section] += 1;
      if (isCorrect) objectiveScores[section] += 1;
      answerResults.push({ questionId: answer.questionId, section, isCorrect, score: isCorrect ? 100 : 0 });
    } else if (section === "writing") {
      const score = scoreWriting(answer.questionId, answer.answer);
      writingTotal += score;
      writingCount += 1;
      answerResults.push({ questionId: answer.questionId, section, isCorrect: score >= 60, score });
    } else if (section === "speaking") {
      const score = scoreSpeaking(answer.answer);
      speakingTotal += score;
      speakingCount += 1;
      answerResults.push({ questionId: answer.questionId, section, isCorrect: score >= 60, score });
    }
  }

  const reading = Math.round((objectiveScores.reading / SECTION_REQUIREMENTS.reading.questionIds.length) * 100);
  const listening = Math.round((objectiveScores.listening / SECTION_REQUIREMENTS.listening.questionIds.length) * 100);
  const writing = writingCount ? Math.round(writingTotal / writingCount) : 0;
  const speaking = speakingCount ? Math.round(speakingTotal / speakingCount) : 0;
  const total = Math.round((reading + listening + writing + speaking) / 4);
  const passed = total >= PASS_THRESHOLD && [reading, listening, writing, speaking].every((score) => score >= MIN_SECTION_SCORE);
  const weakSections: string[] = [
    ["Reading", reading], ["Listening", listening], ["Writing", writing], ["Speaking", speaking],
  ].filter(([, score]) => Number(score) < MIN_SECTION_SCORE).map(([name]) => String(name));
  const feedback = weakSections.length
    ? weakSections.map((section) => `Strengthen your ${section.toLowerCase()} performance before retaking the assessment.`)
    : ["Good balance across all four professional English skills."];

  return {
    total,
    reading,
    listening,
    writing,
    speaking,
    passed,
    cefr: cefrFor(total),
    proficiency: proficiencyFor(total),
    feedback,
    answerResults,
  };
}

export function getSectionForQuestion(questionId: string): AssessmentSection | undefined {
  if (questionId === "speaking_3") return "speaking";
  return allQuestionSections.get(questionId);
}