import {
  type User,
  type InsertUser,
  type TestSession,
  type InsertTestSession,
  type TestAnswer,
  type InsertTestAnswer,
  type Payment,
  type InsertPayment,
  type UserSession,
  type InsertUserSession,
  type TempRegistration,
  type FullTempRegistration,
  users,
  testSessions,
  testAnswers,
  payments,
  userSessions,
  tempRegistrations,
} from "@shared/schema";

import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/node-postgres";
import { eq, and, ne, sql, desc } from "drizzle-orm";
import { Pool } from "pg";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Test Sessions
  getTestSession(id: string): Promise<TestSession | undefined>;
  getTestSessionsByUser(userId: string): Promise<TestSession[]>;
  getTestSessionByRegistrationToken(
    token: string,
  ): Promise<TestSession | undefined>;
  createTestSession(session: InsertTestSession): Promise<TestSession>;

  getOrCreatePaymentSessionForUser(
    session: InsertTestSession & {
      userId: string;
      sessionToken: string;
      sessionTokenExpiresAt: Date;
    },
  ): Promise<{
    session: TestSession;
    created: boolean;
  }>;

  getOrCreatePaymentSessionForRegistration(
    session: InsertTestSession & {
      registrationToken: string;
      sessionToken: string;
      sessionTokenExpiresAt: Date;
    },
  ): Promise<{
    session: TestSession;
    created: boolean;
  }>;

  updateTestSession(
    id: string,
    updates: Partial<TestSession>,
  ): Promise<TestSession | undefined>;

  completeTestSession(
    id: string,
    updates: Partial<TestSession>,
  ): Promise<TestSession | undefined>;

  // Test Answers
  getTestAnswers(sessionId: string): Promise<TestAnswer[]>;
  createTestAnswer(answer: InsertTestAnswer): Promise<TestAnswer>;

  updateTestAnswer(
    id: string,
    updates: Partial<TestAnswer>,
  ): Promise<TestAnswer | undefined>;

  upsertTestAnswer(answer: InsertTestAnswer): Promise<TestAnswer>;

  // Payments
  getPayment(id: string): Promise<Payment | undefined>;
  getPaymentByReference(reference: string): Promise<Payment | undefined>;
  getPaymentsBySession(sessionId: string): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;

  updatePayment(
    id: string,
    updates: Partial<Payment>,
  ): Promise<Payment | undefined>;

  // User Sessions
  getUserSession(token: string): Promise<UserSession | undefined>;
  createUserSession(session: InsertUserSession): Promise<UserSession>;

  getUserSessionByUser(
    userId: string,
    type: string,
  ): Promise<UserSession | undefined>;

  deleteUserSession(token: string): Promise<void>;
  deleteExpiredSessions(): Promise<void>;

  // Temporary Registrations
  getTempRegistration(
    token: string,
  ): Promise<TempRegistration | undefined>;

  getTempRegistrationByEmail(
    email: string,
  ): Promise<TempRegistration | undefined>;

  getProtectedPaymentRegistrationByEmail(
    email: string,
  ): Promise<TempRegistration | undefined>;

  createTempRegistration(
    tempReg: FullTempRegistration,
  ): Promise<TempRegistration>;

  getOrCreateTempRegistration(
    tempReg: FullTempRegistration,
  ): Promise<{
    registration: TempRegistration;
    created: boolean;
    paymentProtected: boolean;
  }>;

  updateTempRegistration(
    token: string,
    updates: Partial<TempRegistration>,
  ): Promise<TempRegistration | undefined>;

  deleteTempRegistration(token: string): Promise<void>;
  deleteExpiredTempRegistrations(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;

  constructor() {
    if (!process.env.DATABASE_URL) {
      console.error(
        "DATABASE_URL environment variable is required",
      );

      throw new Error(
        "DATABASE_URL environment variable is required",
      );
    }

    try {
      const pool = new Pool({
        connectionString:
          process.env.DATABASE_URL,

        max: Number.parseInt(
          process.env.DB_POOL_MAX || "10",
          10,
        ),
      });

      this.db = drizzle(pool, {
        schema: {
          users,
          testSessions,
          testAnswers,
          payments,
          userSessions,
          tempRegistrations,
        },
      });
    } catch (error) {
      console.error(
        "Database connection failed:",
        error,
      );

      throw error;
    }
  }

  // ============================================================
  // USERS
  // ============================================================

  async getUser(
    id: string,
  ): Promise<User | undefined> {
    const result = await this.db
      .select()
      .from(users)
      .where(
        eq(users.id, id),
      )
      .limit(1);

    return result[0];
  }

  async getUserByEmail(
    email: string,
  ): Promise<User | undefined> {
    const result = await this.db
      .select()
      .from(users)
      .where(
        eq(users.email, email),
      )
      .limit(1);

    return result[0];
  }

  async createUser(
    insertUser: InsertUser,
  ): Promise<User> {
    const result = await this.db
      .insert(users)
      .values(insertUser)
      .returning();

    return result[0];
  }

  // ============================================================
  // TEST SESSIONS
  // ============================================================

  async getTestSession(
    id: string,
  ): Promise<TestSession | undefined> {
    const result = await this.db
      .select()
      .from(testSessions)
      .where(
        eq(testSessions.id, id),
      )
      .limit(1);

    return result[0];
  }

  async getTestSessionsByUser(
    userId: string,
  ): Promise<TestSession[]> {
    return await this.db
      .select()
      .from(testSessions)
      .where(
        eq(
          testSessions.userId,
          userId,
        ),
      );
  }

  async getTestSessionByRegistrationToken(
    token: string,
  ): Promise<TestSession | undefined> {
    const result = await this.db
      .select()
      .from(testSessions)
      .where(
        eq(
          testSessions.registrationToken,
          token,
        ),
      )
      .limit(1);

    return result[0];
  }

  async createTestSession(
    insertSession: InsertTestSession,
  ): Promise<TestSession> {
    const result = await this.db
      .insert(testSessions)
      .values(insertSession)
      .returning();

    return result[0];
  }

  async getOrCreatePaymentSessionForUser(
    insertSession: InsertTestSession & {
      userId: string;
      sessionToken: string;
      sessionTokenExpiresAt: Date;
    },
  ): Promise<{
    session: TestSession;
    created: boolean;
  }> {
    return this.db.transaction(
      async (tx) => {
        await tx.execute(
          sql`SELECT pg_advisory_xact_lock(hashtext(${insertSession.userId}))`,
        );

        const existing = await tx
          .select()
          .from(testSessions)
          .where(
            and(
              eq(
                testSessions.userId,
                insertSession.userId,
              ),
              eq(
                testSessions.paymentStatus,
                "pending",
              ),
              eq(
                testSessions.status,
                "pending",
              ),
            ),
          )
          .orderBy(
            desc(
              testSessions.createdAt,
            ),
          )
          .limit(1);

        if (existing[0]) {
          const tokenIsValid =
            Boolean(
              existing[0]
                .sessionToken &&
              existing[0]
                .sessionTokenExpiresAt &&
              existing[0]
                .sessionTokenExpiresAt >
                new Date(),
            );

          if (tokenIsValid) {
            return {
              session:
                existing[0],
              created: false,
            };
          }

          const refreshed =
            await tx
              .update(
                testSessions,
              )
              .set({
                sessionToken:
                  insertSession.sessionToken,

                sessionTokenExpiresAt:
                  insertSession.sessionTokenExpiresAt,
              })
              .where(
                eq(
                  testSessions.id,
                  existing[0].id,
                ),
              )
              .returning();

          return {
            session:
              refreshed[0],
            created: false,
          };
        }

        const created =
          await tx
            .insert(
              testSessions,
            )
            .values(
              insertSession,
            )
            .returning();

        return {
          session:
            created[0],
          created: true,
        };
      },
    );
  }

  async getOrCreatePaymentSessionForRegistration(
    insertSession: InsertTestSession & {
      registrationToken: string;
      sessionToken: string;
      sessionTokenExpiresAt: Date;
    },
  ): Promise<{
    session: TestSession;
    created: boolean;
  }> {
    return this.db.transaction(
      async (tx) => {
        await tx.execute(
          sql`SELECT pg_advisory_xact_lock(hashtext(${
            "registration:" +
            insertSession.registrationToken
          }))`,
        );

        const existing = await tx
          .select()
          .from(testSessions)
          .where(
            eq(
              testSessions.registrationToken,
              insertSession.registrationToken,
            ),
          )
          .orderBy(
            desc(
              testSessions.createdAt,
            ),
          )
          .limit(1);

        if (existing[0]) {
          const tokenIsValid =
            Boolean(
              existing[0]
                .sessionToken &&
              existing[0]
                .sessionTokenExpiresAt &&
              existing[0]
                .sessionTokenExpiresAt >
                new Date(),
            );

          if (tokenIsValid) {
            return {
              session:
                existing[0],
              created: false,
            };
          }

          const refreshed =
            await tx
              .update(
                testSessions,
              )
              .set({
                sessionToken:
                  insertSession.sessionToken,

                sessionTokenExpiresAt:
                  insertSession.sessionTokenExpiresAt,
              })
              .where(
                eq(
                  testSessions.id,
                  existing[0].id,
                ),
              )
              .returning();

          return {
            session:
              refreshed[0],
            created: false,
          };
        }

        const created =
          await tx
            .insert(
              testSessions,
            )
            .values(
              insertSession,
            )
            .returning();

        return {
          session:
            created[0],
          created: true,
        };
      },
    );
  }

  async updateTestSession(
    id: string,
    updates: Partial<TestSession>,
  ): Promise<TestSession | undefined> {
    const result =
      await this.db
        .update(
          testSessions,
        )
        .set(updates)
        .where(
          eq(
            testSessions.id,
            id,
          ),
        )
        .returning();

    return result[0];
  }

  async completeTestSession(
    id: string,
    updates: Partial<TestSession>,
  ): Promise<TestSession | undefined> {
    const result =
      await this.db
        .update(
          testSessions,
        )
        .set(updates)
        .where(
          and(
            eq(
              testSessions.id,
              id,
            ),
            ne(
              testSessions.status,
              "completed",
            ),
          ),
        )
        .returning();

    return (
      result[0] ||
      this.getTestSession(id)
    );
  }

  // ============================================================
  // TEST ANSWERS
  // ============================================================

  async getTestAnswers(
    sessionId: string,
  ): Promise<TestAnswer[]> {
    return await this.db
      .select()
      .from(testAnswers)
      .where(
        eq(
          testAnswers.sessionId,
          sessionId,
        ),
      );
  }

  async createTestAnswer(
    answer: InsertTestAnswer,
  ): Promise<TestAnswer> {
    const result =
      await this.db
        .insert(testAnswers)
        .values(answer)
        .returning();

    return result[0];
  }

  async updateTestAnswer(
    id: string,
    updates: Partial<TestAnswer>,
  ): Promise<TestAnswer | undefined> {
    const result =
      await this.db
        .update(
          testAnswers,
        )
        .set(updates)
        .where(
          eq(
            testAnswers.id,
            id,
          ),
        )
        .returning();

    return result[0];
  }

  async upsertTestAnswer(
    answer: InsertTestAnswer,
  ): Promise<TestAnswer> {
    const result =
      await this.db
        .insert(testAnswers)
        .values(answer)
        .onConflictDoUpdate({
          target: [
            testAnswers.sessionId,
            testAnswers.questionId,
          ],

          set: {
            section:
              answer.section,

            answer:
              answer.answer,

            isCorrect:
              answer.isCorrect,

            score:
              answer.score,
          },
        })
        .returning();

    return result[0];
  }

  // ============================================================
  // PAYMENTS
  // ============================================================

  async getPayment(
    id: string,
  ): Promise<Payment | undefined> {
    const result =
      await this.db
        .select()
        .from(payments)
        .where(
          eq(
            payments.id,
            id,
          ),
        )
        .limit(1);

    return result[0];
  }

  async getPaymentByReference(
    reference: string,
  ): Promise<Payment | undefined> {
    const result =
      await this.db
        .select()
        .from(payments)
        .where(
          eq(
            payments.paystackReference,
            reference,
          ),
        )
        .limit(1);

    return result[0];
  }

  async getPaymentsBySession(
    sessionId: string,
  ): Promise<Payment[]> {
    return await this.db
      .select()
      .from(payments)
      .where(
        eq(
          payments.sessionId,
          sessionId,
        ),
      );
  }

  async createPayment(
    payment: InsertPayment,
  ): Promise<Payment> {
    const result =
      await this.db
        .insert(payments)
        .values(payment)
        .returning();

    return result[0];
  }

  async updatePayment(
    id: string,
    updates: Partial<Payment>,
  ): Promise<Payment | undefined> {
    const result =
      await this.db
        .update(
          payments,
        )
        .set(updates)
        .where(
          eq(
            payments.id,
            id,
          ),
        )
        .returning();

    return result[0];
  }

  // ============================================================
  // USER SESSIONS
  // ============================================================

  async getUserSession(
    token: string,
  ): Promise<UserSession | undefined> {
    const result =
      await this.db
        .select()
        .from(userSessions)
        .where(
          eq(
            userSessions.token,
            token,
          ),
        )
        .limit(1);

    return result[0];
  }

  async createUserSession(
    session: InsertUserSession,
  ): Promise<UserSession> {
    const result =
      await this.db
        .insert(userSessions)
        .values(session)
        .returning();

    return result[0];
  }

  async getUserSessionByUser(
    userId: string,
    type: string,
  ): Promise<UserSession | undefined> {
    const result =
      await this.db
        .select()
        .from(userSessions)
        .where(
          and(
            eq(
              userSessions.userId,
              userId,
            ),
            eq(
              userSessions.type,
              type,
            ),
          ),
        )
        .limit(1);

    return result[0];
  }

  async deleteUserSession(
    token: string,
  ): Promise<void> {
    await this.db
      .delete(userSessions)
      .where(
        eq(
          userSessions.token,
          token,
        ),
      );
  }

  async deleteExpiredSessions(): Promise<void> {
    const now =
      new Date();

    await this.db
      .delete(userSessions)
      .where(
        sql`expires_at < ${now}`,
      );
  }

  // ============================================================
  // TEMPORARY REGISTRATIONS
  // ============================================================

  async getTempRegistration(
    token: string,
  ): Promise<TempRegistration | undefined> {
    const result =
      await this.db
        .select()
        .from(tempRegistrations)
        .where(
          eq(
            tempRegistrations.token,
            token,
          ),
        )
        .limit(1);

    return result[0];
  }

  async getTempRegistrationByEmail(
    email: string,
  ): Promise<TempRegistration | undefined> {
    const result =
      await this.db
        .select()
        .from(tempRegistrations)
        .where(
          eq(
            tempRegistrations.email,
            email,
          ),
        )
        .orderBy(
          desc(
            tempRegistrations.createdAt,
          ),
        )
        .limit(1);

    return result[0];
  }

  /**
   * Only a SUCCESSFUL payment permanently protects a registration.
   *
   * Pending/failed/cancelled/expired payments should not stop a user from
   * submitting their registration details again.
   */
  async getProtectedPaymentRegistrationByEmail(
    email: string,
  ): Promise<TempRegistration | undefined> {
    const result =
      await this.db
        .select({
          registration:
            tempRegistrations,
        })
        .from(
          tempRegistrations,
        )
        .innerJoin(
          testSessions,
          eq(
            testSessions.registrationToken,
            tempRegistrations.token,
          ),
        )
        .innerJoin(
          payments,
          and(
            eq(
              payments.sessionId,
              testSessions.id,
            ),
            eq(
              payments.status,
              "success",
            ),
          ),
        )
        .where(
          eq(
            tempRegistrations.email,
            email,
          ),
        )
        .limit(1);

    return (
      result[0]?.registration
    );
  }

  async createTempRegistration(
    tempReg: FullTempRegistration,
  ): Promise<TempRegistration> {
    const result =
      await this.db
        .insert(
          tempRegistrations,
        )
        .values(
          tempReg,
        )
        .returning();

    return result[0];
  }

  /**
   * Registration behavior:
   *
   * SUCCESSFUL PAYMENT:
   *   protected permanently
   *
   * PENDING / CANCELLED / FAILED / EXPIRED:
   *   registration may be reused
   *
   * The payment endpoint is responsible for determining whether an STK request
   * is still active or whether a fresh STK can safely be initiated.
   */
  async getOrCreateTempRegistration(
    tempReg: FullTempRegistration,
  ): Promise<{
    registration: TempRegistration;
    created: boolean;
    paymentProtected: boolean;
  }> {
    return this.db.transaction(
      async (tx) => {
        /**
         * Prevent two simultaneous registration requests using the same email
         * from creating duplicate temporary registrations.
         */
        await tx.execute(
          sql`SELECT pg_advisory_xact_lock(hashtext(${
            "temp-registration:" +
            tempReg.email
          }))`,
        );

        /**
         * A successful payment is the only state that permanently protects
         * the registration.
         */
        const protectedRegistration =
          await tx
            .select({
              registration:
                tempRegistrations,
            })
            .from(
              tempRegistrations,
            )
            .innerJoin(
              testSessions,
              eq(
                testSessions.registrationToken,
                tempRegistrations.token,
              ),
            )
            .innerJoin(
              payments,
              and(
                eq(
                  payments.sessionId,
                  testSessions.id,
                ),
                eq(
                  payments.status,
                  "success",
                ),
              ),
            )
            .where(
              eq(
                tempRegistrations.email,
                tempReg.email,
              ),
            )
            .limit(1);

        if (
          protectedRegistration[0]
        ) {
          return {
            registration:
              protectedRegistration[0]
                .registration,

            created: false,

            paymentProtected:
              true,
          };
        }

        /**
         * Reuse the latest active temporary registration.
         *
         * We deliberately do not block this just because an earlier payment
         * is still marked pending. palpluss.ts will reconcile that payment
         * before allowing a new STK push.
         */
        const existing =
          await tx
            .select()
            .from(
              tempRegistrations,
            )
            .where(
              and(
                eq(
                  tempRegistrations.email,
                  tempReg.email,
                ),
                sql`${tempRegistrations.expiresAt} > NOW()`,
              ),
            )
            .orderBy(
              desc(
                tempRegistrations.createdAt,
              ),
            )
            .limit(1);

        if (existing[0]) {
          /**
           * Refresh expiry so the person can continue immediately.
           */
          const refreshed =
            await tx
              .update(
                tempRegistrations,
              )
              .set({
                expiresAt:
                  tempReg.expiresAt,
              })
              .where(
                eq(
                  tempRegistrations.token,
                  existing[0].token,
                ),
              )
              .returning();

          return {
            registration:
              refreshed[0] ||
              existing[0],

            created: false,

            paymentProtected:
              false,
          };
        }

        /**
         * Delete old expired registrations that have no successful payment.
         */
        await tx
          .delete(
            tempRegistrations,
          )
          .where(
            and(
              eq(
                tempRegistrations.email,
                tempReg.email,
              ),
              sql`${tempRegistrations.expiresAt} <= NOW()`,
              sql`NOT EXISTS (
                SELECT 1
                FROM ${testSessions}
                INNER JOIN ${payments}
                  ON ${payments.sessionId} = ${testSessions.id}
                WHERE ${testSessions.registrationToken} = ${tempRegistrations.token}
                  AND ${payments.status} = 'success'
              )`,
            ),
          );

        /**
         * Create brand-new temporary registration.
         */
        const created =
          await tx
            .insert(
              tempRegistrations,
            )
            .values(
              tempReg,
            )
            .returning();

        return {
          registration:
            created[0],

          created: true,

          paymentProtected:
            false,
        };
      },
    );
  }

  async updateTempRegistration(
    token: string,
    updates: Partial<TempRegistration>,
  ): Promise<TempRegistration | undefined> {
    const result =
      await this.db
        .update(
          tempRegistrations,
        )
        .set(updates)
        .where(
          eq(
            tempRegistrations.token,
            token,
          ),
        )
        .returning();

    return result[0];
  }

  async deleteTempRegistration(
    token: string,
  ): Promise<void> {
    await this.db
      .delete(
        tempRegistrations,
      )
      .where(
        eq(
          tempRegistrations.token,
          token,
        ),
      );
  }

  /**
   * Expired registrations are preserved ONLY when they belong to a successful
   * payment.
   *
   * Pending/cancelled/failed registrations should not remain forever.
   */
  async deleteExpiredTempRegistrations(): Promise<void> {
    await this.db
      .delete(
        tempRegistrations,
      )
      .where(
        and(
          sql`${tempRegistrations.expiresAt} < NOW()`,

          sql`NOT EXISTS (
            SELECT 1
            FROM ${testSessions}
            INNER JOIN ${payments}
              ON ${payments.sessionId} = ${testSessions.id}
            WHERE ${testSessions.registrationToken} = ${tempRegistrations.token}
              AND ${payments.status} = 'success'
          )`,
        ),
      );
  }
}

// ============================================================
// MEMORY STORAGE
// ============================================================

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private testSessions: Map<
    string,
    TestSession
  >;
  private testAnswers: Map<
    string,
    TestAnswer
  >;
  private payments: Map<
    string,
    Payment
  >;
  private tempRegistrations: Map<
    string,
    TempRegistration
  >;

  private userSessions: Map<
    string,
    UserSession
  > = new Map();

  constructor() {
    this.users =
      new Map();

    this.testSessions =
      new Map();

    this.testAnswers =
      new Map();

    this.payments =
      new Map();

    this.tempRegistrations =
      new Map();
  }

  // ============================================================
  // USERS
  // ============================================================

  async getUser(
    id: string,
  ): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(
    email: string,
  ): Promise<User | undefined> {
    return Array.from(
      this.users.values(),
    ).find(
      (user) =>
        user.email === email,
    );
  }

  async createUser(
    insertUser: InsertUser,
  ): Promise<User> {
    const id =
      randomUUID();

    const user: User = {
      ...insertUser,
      id,
      createdAt:
        new Date(),
    };

    this.users.set(
      id,
      user,
    );

    return user;
  }

  // ============================================================
  // TEST SESSIONS
  // ============================================================

  async getTestSession(
    id: string,
  ): Promise<TestSession | undefined> {
    return this.testSessions.get(
      id,
    );
  }

  async getTestSessionsByUser(
    userId: string,
  ): Promise<TestSession[]> {
    return Array.from(
      this.testSessions.values(),
    ).filter(
      (session) =>
        session.userId ===
        userId,
    );
  }

  async getTestSessionByRegistrationToken(
    token: string,
  ): Promise<TestSession | undefined> {
    return Array.from(
      this.testSessions.values(),
    ).find(
      (session) =>
        session.registrationToken ===
        token,
    );
  }

  async createTestSession(
    insertSession: InsertTestSession,
  ): Promise<TestSession> {
    const id =
      randomUUID();

    const session: TestSession = {
      ...insertSession,

      id,

      userId:
        insertSession.userId ??
        null,

      status:
        insertSession.status ||
        "pending",

      paymentStatus:
        insertSession.paymentStatus ||
        "pending",

      startedAt:
        insertSession.startedAt ||
        null,

      completedAt:
        insertSession.completedAt ||
        null,

      totalScore:
        insertSession.totalScore ||
        null,

      readingScore:
        insertSession.readingScore ||
        null,

      listeningScore:
        insertSession.listeningScore ||
        null,

      writingScore:
        insertSession.writingScore ||
        null,

      speakingScore:
        insertSession.speakingScore ||
        null,

      certificateId:
        insertSession.certificateId ||
        null,

      paymentId:
        insertSession.paymentId ||
        null,

      passed:
        insertSession.passed ??
        false,

      resultDetails:
        insertSession.resultDetails ??
        null,

      certificateIssuedAt:
        insertSession.certificateIssuedAt ??
        null,

      sessionToken:
        insertSession.sessionToken ??
        null,

      sessionTokenExpiresAt:
        insertSession.sessionTokenExpiresAt ??
        null,

      registrationToken:
        insertSession.registrationToken ??
        null,

      createdAt:
        new Date(),
    };

    this.testSessions.set(
      id,
      session,
    );

    return session;
  }

  async getOrCreatePaymentSessionForUser(
    insertSession: InsertTestSession & {
      userId: string;
      sessionToken: string;
      sessionTokenExpiresAt: Date;
    },
  ): Promise<{
    session: TestSession;
    created: boolean;
  }> {
    const existing =
      Array.from(
        this.testSessions.values(),
      )
        .filter(
          (session) =>
            session.userId ===
              insertSession.userId &&
            session.paymentStatus ===
              "pending" &&
            session.status ===
              "pending",
        )
        .sort(
          (a, b) =>
            b.createdAt.getTime() -
            a.createdAt.getTime(),
        )[0];

    if (existing) {
      const tokenIsValid =
        Boolean(
          existing.sessionToken &&
          existing.sessionTokenExpiresAt &&
          existing.sessionTokenExpiresAt >
            new Date(),
        );

      if (tokenIsValid) {
        return {
          session:
            existing,
          created: false,
        };
      }

      const refreshed: TestSession = {
        ...existing,

        sessionToken:
          insertSession.sessionToken,

        sessionTokenExpiresAt:
          insertSession.sessionTokenExpiresAt,
      };

      this.testSessions.set(
        existing.id,
        refreshed,
      );

      return {
        session:
          refreshed,
        created: false,
      };
    }

    return {
      session:
        await this.createTestSession(
          insertSession,
        ),

      created: true,
    };
  }

  async getOrCreatePaymentSessionForRegistration(
    insertSession: InsertTestSession & {
      registrationToken: string;
      sessionToken: string;
      sessionTokenExpiresAt: Date;
    },
  ): Promise<{
    session: TestSession;
    created: boolean;
  }> {
    const existing =
      Array.from(
        this.testSessions.values(),
      )
        .filter(
          (session) =>
            session.registrationToken ===
            insertSession.registrationToken,
        )
        .sort(
          (a, b) =>
            b.createdAt.getTime() -
            a.createdAt.getTime(),
        )[0];

    if (existing) {
      const tokenIsValid =
        Boolean(
          existing.sessionToken &&
          existing.sessionTokenExpiresAt &&
          existing.sessionTokenExpiresAt >
            new Date(),
        );

      if (tokenIsValid) {
        return {
          session:
            existing,
          created: false,
        };
      }

      const refreshed: TestSession = {
        ...existing,

        sessionToken:
          insertSession.sessionToken,

        sessionTokenExpiresAt:
          insertSession.sessionTokenExpiresAt,
      };

      this.testSessions.set(
        existing.id,
        refreshed,
      );

      return {
        session:
          refreshed,
        created: false,
      };
    }

    return {
      session:
        await this.createTestSession(
          insertSession,
        ),

      created: true,
    };
  }

  async updateTestSession(
    id: string,
    updates: Partial<TestSession>,
  ): Promise<TestSession | undefined> {
    const session =
      this.testSessions.get(id);

    if (!session) {
      return undefined;
    }

    const updatedSession = {
      ...session,
      ...updates,
    };

    this.testSessions.set(
      id,
      updatedSession,
    );

    return updatedSession;
  }

  async completeTestSession(
    id: string,
    updates: Partial<TestSession>,
  ): Promise<TestSession | undefined> {
    const session =
      this.testSessions.get(id);

    if (!session) {
      return undefined;
    }

    if (
      session.status ===
      "completed"
    ) {
      return session;
    }

    const completed = {
      ...session,
      ...updates,
    };

    this.testSessions.set(
      id,
      completed,
    );

    return completed;
  }

  // ============================================================
  // TEST ANSWERS
  // ============================================================

  async getTestAnswers(
    sessionId: string,
  ): Promise<TestAnswer[]> {
    return Array.from(
      this.testAnswers.values(),
    ).filter(
      (answer) =>
        answer.sessionId ===
        sessionId,
    );
  }

  async createTestAnswer(
    insertAnswer: InsertTestAnswer,
  ): Promise<TestAnswer> {
    const id =
      randomUUID();

    const answer: TestAnswer = {
      ...insertAnswer,

      id,

      answer:
        insertAnswer.answer ||
        null,

      isCorrect:
        insertAnswer.isCorrect ||
        null,

      score:
        insertAnswer.score ||
        null,

      createdAt:
        new Date(),
    };

    this.testAnswers.set(
      id,
      answer,
    );

    return answer;
  }

  async updateTestAnswer(
    id: string,
    updates: Partial<TestAnswer>,
  ): Promise<TestAnswer | undefined> {
    const answer =
      this.testAnswers.get(id);

    if (!answer) {
      return undefined;
    }

    const updatedAnswer = {
      ...answer,
      ...updates,
    };

    this.testAnswers.set(
      id,
      updatedAnswer,
    );

    return updatedAnswer;
  }

  async upsertTestAnswer(
    insertAnswer: InsertTestAnswer,
  ): Promise<TestAnswer> {
    const existingAnswer =
      Array.from(
        this.testAnswers.values(),
      ).find(
        (answer) =>
          answer.sessionId ===
            insertAnswer.sessionId &&
          answer.section ===
            insertAnswer.section &&
          answer.questionId ===
            insertAnswer.questionId,
      );

    if (existingAnswer) {
      const updatedAnswer = {
        ...existingAnswer,

        answer:
          insertAnswer.answer ||
          existingAnswer.answer,

        isCorrect:
          insertAnswer.isCorrect ??
          existingAnswer.isCorrect,

        score:
          insertAnswer.score ??
          existingAnswer.score,
      };

      this.testAnswers.set(
        existingAnswer.id,
        updatedAnswer,
      );

      return updatedAnswer;
    }

    return this.createTestAnswer(
      insertAnswer,
    );
  }

  // ============================================================
  // PAYMENTS
  // ============================================================

  async getPayment(
    id: string,
  ): Promise<Payment | undefined> {
    return this.payments.get(
      id,
    );
  }

  async getPaymentByReference(
    reference: string,
  ): Promise<Payment | undefined> {
    return Array.from(
      this.payments.values(),
    ).find(
      (payment) =>
        payment.paystackReference ===
        reference,
    );
  }

  async getPaymentsBySession(
    sessionId: string,
  ): Promise<Payment[]> {
    return Array.from(
      this.payments.values(),
    ).filter(
      (payment) =>
        payment.sessionId ===
        sessionId,
    );
  }

  /**
   * Allow unlimited historical attempts, but only ONE pending attempt at a time.
   */
  async createPayment(
    insertPayment: InsertPayment,
  ): Promise<Payment> {
    const duplicate =
      Array.from(
        this.payments.values(),
      ).some(
        (payment) =>
          payment.paystackReference ===
            insertPayment.paystackReference,
      );

    if (duplicate) {
      throw new Error(
        "Duplicate or concurrent payment attempt",
      );
    }

    const id =
      randomUUID();

    const payment: Payment = {
      ...insertPayment,

      id,

      status:
        insertPayment.status ||
        "pending",

      currency:
        insertPayment.currency ||
        "KES",

      provider:
        insertPayment.provider ||
        "palpluss",

      metadata:
        insertPayment.metadata ??
        null,

      createdAt:
        new Date(),
    };

    this.payments.set(
      id,
      payment,
    );

    return payment;
  }

  async updatePayment(
    id: string,
    updates: Partial<Payment>,
  ): Promise<Payment | undefined> {
    const payment =
      this.payments.get(id);

    if (!payment) {
      return undefined;
    }

    const updatedPayment = {
      ...payment,
      ...updates,
    };

    this.payments.set(
      id,
      updatedPayment,
    );

    return updatedPayment;
  }

  // ============================================================
  // USER SESSIONS
  // ============================================================

  async getUserSession(
    token: string,
  ): Promise<UserSession | undefined> {
    return this.userSessions.get(
      token,
    );
  }

  async createUserSession(
    session: InsertUserSession,
  ): Promise<UserSession> {
    const id =
      randomUUID();

    const userSession: UserSession = {
      ...session,

      id,

      createdAt:
        new Date(),
    };

    this.userSessions.set(
      session.token,
      userSession,
    );

    return userSession;
  }

  async getUserSessionByUser(
    userId: string,
    type: string,
  ): Promise<UserSession | undefined> {
    return Array.from(
      this.userSessions.values(),
    ).find(
      (session) =>
        session.userId ===
          userId &&
        session.type ===
          type,
    );
  }

  async deleteUserSession(
    token: string,
  ): Promise<void> {
    this.userSessions.delete(
      token,
    );
  }

  async deleteExpiredSessions(): Promise<void> {
    const now =
      new Date();

    const tokensToDelete:
      string[] = [];

    this.userSessions.forEach(
      (
        session,
        token,
      ) => {
        if (
          session.expiresAt <
          now
        ) {
          tokensToDelete.push(
            token,
          );
        }
      },
    );

    tokensToDelete.forEach(
      (token) => {
        this.userSessions.delete(
          token,
        );
      },
    );
  }

  // ============================================================
  // TEMPORARY REGISTRATIONS
  // ============================================================

  async getTempRegistration(
    token: string,
  ): Promise<TempRegistration | undefined> {
    return this.tempRegistrations.get(
      token,
    );
  }

  async getTempRegistrationByEmail(
    email: string,
  ): Promise<TempRegistration | undefined> {
    return Array.from(
      this.tempRegistrations.values(),
    )
      .filter(
        (registration) =>
          registration.email ===
          email,
      )
      .sort(
        (a, b) =>
          b.createdAt.getTime() -
          a.createdAt.getTime(),
      )[0];
  }

  /**
   * Only a successful payment permanently protects registration.
   */
  async getProtectedPaymentRegistrationByEmail(
    email: string,
  ): Promise<TempRegistration | undefined> {
    return Array.from(
      this.tempRegistrations.values(),
    ).find(
      (registration) => {
        if (
          registration.email !==
          email
        ) {
          return false;
        }

        const sessionIds =
          Array.from(
            this.testSessions.values(),
          )
            .filter(
              (session) =>
                session.registrationToken ===
                registration.token,
            )
            .map(
              (session) =>
                session.id,
            );

        return Array.from(
          this.payments.values(),
        ).some(
          (payment) =>
            sessionIds.includes(
              payment.sessionId,
            ) &&
            payment.status ===
              "success",
        );
      },
    );
  }

  async createTempRegistration(
    tempReg: FullTempRegistration,
  ): Promise<TempRegistration> {
    const id =
      randomUUID();

    const tempRegistration: TempRegistration = {
      ...tempReg,

      id,

      createdAt:
        new Date(),
    };

    this.tempRegistrations.set(
      tempReg.token,
      tempRegistration,
    );

    return tempRegistration;
  }

  async getOrCreateTempRegistration(
    tempReg: FullTempRegistration,
  ): Promise<{
    registration: TempRegistration;
    created: boolean;
    paymentProtected: boolean;
  }> {
    /**
     * A successful payment is the only permanent protection.
     */
    const protectedRegistration =
      await this.getProtectedPaymentRegistrationByEmail(
        tempReg.email,
      );

    if (
      protectedRegistration
    ) {
      return {
        registration:
          protectedRegistration,

        created: false,

        paymentProtected:
          true,
      };
    }

    /**
     * Reuse latest active registration.
     */
    const existing =
      Array.from(
        this.tempRegistrations.values(),
      )
        .filter(
          (registration) =>
            registration.email ===
              tempReg.email &&
            registration.expiresAt >
              new Date(),
        )
        .sort(
          (a, b) =>
            b.createdAt.getTime() -
            a.createdAt.getTime(),
        )[0];

    if (existing) {
      const refreshed: TempRegistration = {
        ...existing,

        expiresAt:
          tempReg.expiresAt,
      };

      this.tempRegistrations.set(
        existing.token,
        refreshed,
      );

      return {
        registration:
          refreshed,

        created: false,

        paymentProtected:
          false,
      };
    }

    /**
     * Remove expired registrations that do not own a successful payment.
     */
    for (
      const [
        token,
        registration,
      ] of Array.from(
        this.tempRegistrations.entries(),
      )
    ) {
      if (
        registration.email ===
          tempReg.email &&
        registration.expiresAt <=
          new Date()
      ) {
        const ownsSuccessfulPayment =
          Array.from(
            this.testSessions.values(),
          ).some(
            (session) =>
              session.registrationToken ===
                token &&
              Array.from(
                this.payments.values(),
              ).some(
                (payment) =>
                  payment.sessionId ===
                    session.id &&
                  payment.status ===
                    "success",
              ),
          );

        if (
          !ownsSuccessfulPayment
        ) {
          this.tempRegistrations.delete(
            token,
          );
        }
      }
    }

    return {
      registration:
        await this.createTempRegistration(
          tempReg,
        ),

      created: true,

      paymentProtected:
        false,
    };
  }

  async updateTempRegistration(
    token: string,
    updates: Partial<TempRegistration>,
  ): Promise<TempRegistration | undefined> {
    const registration =
      this.tempRegistrations.get(
        token,
      );

    if (!registration) {
      return undefined;
    }

    const updated = {
      ...registration,
      ...updates,
    };

    this.tempRegistrations.set(
      token,
      updated,
    );

    return updated;
  }

  async deleteTempRegistration(
    token: string,
  ): Promise<void> {
    this.tempRegistrations.delete(
      token,
    );
  }

  async deleteExpiredTempRegistrations(): Promise<void> {
    const now =
      new Date();

    const tokensToDelete:
      string[] = [];

    this.tempRegistrations.forEach(
      (
        tempReg,
        token,
      ) => {
        /**
         * Only successful payments permanently preserve an expired
         * registration.
         */
        const ownsSuccessfulPayment =
          Array.from(
            this.testSessions.values(),
          ).some(
            (session) =>
              session.registrationToken ===
                token &&
              Array.from(
                this.payments.values(),
              ).some(
                (payment) =>
                  payment.sessionId ===
                    session.id &&
                  payment.status ===
                    "success",
              ),
          );

        if (
          tempReg.expiresAt <
            now &&
          !ownsSuccessfulPayment
        ) {
          tokensToDelete.push(
            token,
          );
        }
      },
    );

    tokensToDelete.forEach(
      (token) => {
        this.tempRegistrations.delete(
          token,
        );
      },
    );
  }
}

/**
 * PostgreSQL is the normal runtime.
 *
 * Memory storage remains available for local development only.
 */
export const storage =
  process.env.DATABASE_URL
    ? new DatabaseStorage()
    : process.env.NODE_ENV ===
        "production"
      ? (() => {
          throw new Error(
            "DATABASE_URL environment variable is required in production",
          );
        })()
      : new MemStorage();
