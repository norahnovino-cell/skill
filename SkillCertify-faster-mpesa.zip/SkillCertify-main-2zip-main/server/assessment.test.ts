import test from "node:test";
import assert from "node:assert/strict";
import { insertTempRegistrationSchema, type TestAnswer } from "@shared/schema";
import {
  SECTION_REQUIREMENTS,
  scoreAssessment,
  validateAssessmentAnswers,
} from "./assessment";
import {
  createPalPlussAccountReference,
  isActiveTransaction,
  isConfirmedFailedTransaction,
  isDefinitivePalPlussRejection,
  isExplicitProviderRejection,
  isPaymentPhoneAuthorized,
  isPaymentSessionPaid,
  isSuccessfulTransaction,
  runFinalizationOnce,
  TEST_PRICE_KES,
  validatePalPlussApiKey,
  validatePalPlussCallbackUrl,
} from "./palpluss";
import { MemStorage } from "./storage";
import { validateAudioSubmission } from "./audio-validation";

const objectiveAnswers: Record<string, unknown> = {
  reading_1: "b",
  reading_2: "b",
  reading_3: "true",
  reading_4: "intermittent",
  reading_5: "b",
  reading_6: "c",
  reading_7: "false",
  reading_8: "Surgery simulations, ancient civilizations",
  reading_9: "b",
  reading_10: "energy-storage,ai-learning,vr-surgery,grid-infrastructure",
  reading_11: "b",
  reading_12: "true",
  reading_13: "human connection",
  reading_14: "Denmark, Germany",
  reading_15: "b",
  listening_1: "b",
  listening_2: "b",
  listening_3: "a",
  listening_4: "250",
  listening_5: "5",
  listening_6: "AI integration, voice control",
  listening_7: "a",
  listening_8: "12",
  listening_9: "d",
  listening_10: "Multilingual workforce, tech hubs",
};

function essay(minimumWords: number, signals: string[]): string {
  const paragraphs = [
    `Executive summary and recommendation: ${signals.join(" ")}.`,
    "This professional analysis presents evidence, examples, practical implications, risks, and measurable outcomes for international teams.",
    "In conclusion, the proposed approach balances employee needs, communication quality, implementation cost, and sustainable benefit.",
  ];
  let index = 0;
  while (paragraphs.join(" ").split(/\s+/).length < minimumWords + 20) {
    paragraphs[1] += ` evidence${index} perspective${index} outcome${index}`;
    index += 1;
  }
  return paragraphs.join("\n\n");
}

function answer(questionId: string, section: string, value: unknown): TestAnswer {
  return {
    id: `id-${questionId}`,
    sessionId: "session-1",
    questionId,
    section,
    answer: value,
    isCorrect: null,
    score: null,
    createdAt: new Date(),
  };
}

function completeAnswers(): TestAnswer[] {
  const answers = Object.entries(objectiveAnswers).map(([questionId, value]) =>
    answer(questionId, questionId.startsWith("reading") ? "reading" : "listening", value),
  );
  answers.push(
    answer("writing_1", "writing", essay(150, ["executive", "summary", "recommendation", "benefit", "cost", "employee", "wellness", "implement", "program"])),
    answer("writing_2", "writing", essay(250, ["agree", "disagree", "example", "advantage", "benefit", "disadvantage", "problem", "conclusion", "society", "communication"])),
    answer("speaking_1", "speaking", { audioData: `data:audio/webm;base64,${Buffer.alloc(120_000, 1).toString("base64")}`, size: 120_000, durationSeconds: 60, verifiedAudio: true }),
    answer("speaking_2", "speaking", { audioData: `data:audio/webm;base64,${Buffer.alloc(120_000, 2).toString("base64")}`, size: 120_000, durationSeconds: 60, verifiedAudio: true }),
  );
  return answers;
}

test("registration rejects weak credentials and invalid Kenyan phones", () => {
  assert.equal(insertTempRegistrationSchema.safeParse({
    firstName: "A",
    lastName: "B",
    email: "not-an-email",
    phone: "123",
    password: "short",
  }).success, false);
  assert.equal(insertTempRegistrationSchema.safeParse({
    firstName: "Nora",
    lastName: "Novino",
    email: "NORA@example.com",
    phone: "0712345678",
    password: "strong-pass",
  }).success, true);
});

test("submission validation rejects missing answers and short writing", () => {
  const incomplete = completeAnswers().filter((item) => item.questionId !== "listening_10");
  assert.equal(validateAssessmentAnswers(incomplete).valid, false);
  assert.deepEqual(validateAssessmentAnswers(incomplete).missing, ["listening_10"]);

  const shortWriting = completeAnswers().map((item) =>
    item.questionId === "writing_2" ? { ...item, answer: "Too short." } : item,
  );
  const validation = validateAssessmentAnswers(shortWriting);
  assert.equal(validation.valid, false);
  assert.match(validation.invalid.join(" "), /minimum 250 words/);
});

test("server scoring passes strong complete work and withholds eligibility from weak work", () => {
  const strong = scoreAssessment(completeAnswers());
  assert.equal(strong.passed, true);
  assert.equal(strong.reading, 100);
  assert.equal(strong.listening, 100);
  assert.ok(strong.total >= 70);

  const weak = completeAnswers().map((item) =>
    item.section === "reading" ? { ...item, answer: "incorrect" } : item,
  );
  const weakResult = scoreAssessment(weak);
  assert.equal(weakResult.passed, false);
  assert.equal(weakResult.reading, 0);
  assert.ok(weakResult.feedback.some((item) => item.includes("reading")));
});

test("PalPluss success requires exact status, amount, and currency", () => {
  assert.equal(isSuccessfulTransaction({ status: "SUCCESS", amount: TEST_PRICE_KES, currency: "KES" }), true);
  assert.equal(isSuccessfulTransaction({ status: "SUCCESS", amount: TEST_PRICE_KES - 1, currency: "KES" }), false);
  assert.equal(isSuccessfulTransaction({ status: "SUCCESS", amount: TEST_PRICE_KES, currency: "USD" }), false);
  assert.equal(isSuccessfulTransaction({ status: "PENDING", amount: TEST_PRICE_KES, currency: "KES" }), false);
});

test("PalPluss configuration rejects malformed credentials and callback URLs", () => {
  assert.doesNotThrow(() => validatePalPlussApiKey("palpluss_test_key"));
  assert.throws(() => validatePalPlussApiKey(undefined), /invalid format/);
  assert.throws(() => validatePalPlussApiKey(" key-with-whitespace "), /invalid format/);
  assert.doesNotThrow(() => validatePalPlussCallbackUrl("https://payments.example.com/palpluss/webhook"));
  assert.throws(() => validatePalPlussCallbackUrl("http://payments.example.com/webhook"), /HTTPS callback URL/);
  assert.throws(() => validatePalPlussCallbackUrl("not-a-url"), /HTTPS callback URL/);
  const accountReference = createPalPlussAccountReference("attempt_12345678-abcd-efgh");
  assert.equal(accountReference, "EP12345678ab");
  assert.equal(accountReference.length, 12);
});

test("only explicit provider rejection is safe to retry after initiation", () => {
  assert.equal(isDefinitivePalPlussRejection(400, "INVALID_PHONE"), true);
  assert.equal(isDefinitivePalPlussRejection(400, "NO_DEFAULT_CHANNEL"), true);
  assert.equal(isDefinitivePalPlussRejection(402, "INSUFFICIENT_SERVICE_BALANCE"), true);
  assert.equal(isDefinitivePalPlussRejection(429, "STK_TEMP_BANNED"), true);
  assert.equal(isDefinitivePalPlussRejection(409, undefined), false);
  assert.equal(isDefinitivePalPlussRejection(200, undefined), false);
  assert.equal(isDefinitivePalPlussRejection(500, "INVALID_PHONE"), false);
  assert.equal(isExplicitProviderRejection({
    providerResponse: true,
    explicitRejection: true,
  }), true);
  assert.equal(isExplicitProviderRejection({
    providerResponse: true,
    explicitRejection: false,
  }), false);
  assert.equal(isExplicitProviderRejection(new Error("network timeout")), false);
});

test("PalPluss statuses separate active, confirmed failure, and unknown outcomes", () => {
  assert.equal(isActiveTransaction({ status: "PENDING" }), true);
  assert.equal(isActiveTransaction({ status: "PROCESSING" }), true);
  assert.equal(isConfirmedFailedTransaction({ status: "FAILED" }), true);
  assert.equal(isConfirmedFailedTransaction({ status: "CANCELLED" }), true);
  assert.equal(isConfirmedFailedTransaction({ status: "EXPIRED" }), true);
  assert.equal(isConfirmedFailedTransaction({ status: "UNRECOGNIZED" }), false);
  assert.equal(isActiveTransaction({ status: "UNRECOGNIZED" }), false);
});

test("completed sessions and successful payment records block further payment", () => {
  assert.equal(isPaymentSessionPaid("completed", []), true);
  assert.equal(isPaymentSessionPaid("pending", [{ status: "success" }]), true);
  assert.equal(isPaymentSessionPaid("pending", [{ status: "failed" }]), false);
});

test("payment ownership accepts only the registered phone after normalization", () => {
  assert.equal(isPaymentPhoneAuthorized("0712345678", "+254712345678"), true);
  assert.equal(isPaymentPhoneAuthorized("0712345678", "+254722222222"), false);
});

test("duplicate callbacks share one finalization operation", async () => {
  let calls = 0;
  const worker = async () => {
    calls += 1;
    await new Promise((resolve) => setTimeout(resolve, 5));
    return "finalized";
  };
  const results = await Promise.all([
    runFinalizationOnce("callback-reference", worker),
    runFinalizationOnce("callback-reference", worker),
  ]);
  assert.deepEqual(results, ["finalized", "finalized"]);
  assert.equal(calls, 1);
});

test("storage refuses concurrent pending payments for one session", async () => {
  const memory = new MemStorage();
  await memory.createPayment({
    sessionId: "session-1",
    paystackReference: "attempt-1",
    amount: TEST_PRICE_KES,
    currency: "KES",
    provider: "palpluss",
    status: "pending",
  });
  await assert.rejects(() => memory.createPayment({
    sessionId: "session-1",
    paystackReference: "attempt-2",
    amount: TEST_PRICE_KES,
    currency: "KES",
    provider: "palpluss",
    status: "pending",
  }));
});

test("confirmed payment failure releases the session for one safe retry", async () => {
  const memory = new MemStorage();
  const first = await memory.createPayment({
    sessionId: "retry-session",
    paystackReference: "first-attempt",
    amount: TEST_PRICE_KES,
    currency: "KES",
    provider: "palpluss",
    status: "pending",
  });
  await memory.updatePayment(first.id, { status: "failed" });
  const retry = await memory.createPayment({
    sessionId: "retry-session",
    paystackReference: "second-attempt",
    amount: TEST_PRICE_KES,
    currency: "KES",
    provider: "palpluss",
    status: "pending",
  });
  assert.equal(retry.status, "pending");
  const payments = await memory.getPaymentsBySession("retry-session");
  assert.equal(payments.filter((payment) => payment.status === "pending").length, 1);
  assert.equal(payments.filter((payment) => payment.status === "failed").length, 1);
});

test("authenticated retakes acquire one durable session across reloads and devices", async () => {
  const memory = new MemStorage();
  const sessionData = {
    userId: "returning-user",
    status: "pending",
    paymentStatus: "pending",
    sessionToken: "initial-session-token",
    sessionTokenExpiresAt: new Date(Date.now() + 60_000),
  } as const;
  const [firstClient, secondClient] = await Promise.all([
    memory.getOrCreatePaymentSessionForUser(sessionData),
    memory.getOrCreatePaymentSessionForUser(sessionData),
  ]);
  assert.equal(firstClient.session.id, secondClient.session.id);
  assert.equal([firstClient.created, secondClient.created].filter(Boolean).length, 1);

  const payment = await memory.createPayment({
    sessionId: firstClient.session.id,
    paystackReference: "attempt-unresolved",
    amount: TEST_PRICE_KES,
    currency: "KES",
    provider: "palpluss",
    status: "pending",
  });
  assert.equal(
    (await memory.getOrCreatePaymentSessionForUser(sessionData)).session.id,
    firstClient.session.id,
  );
  await memory.updatePayment(payment.id, { status: "failed" });
  assert.equal(
    (await memory.getOrCreatePaymentSessionForUser(sessionData)).session.id,
    firstClient.session.id,
  );

  await memory.updateTestSession(firstClient.session.id, {
    sessionToken: "expired-token",
    sessionTokenExpiresAt: new Date(Date.now() - 1),
  });
  const refreshData = {
    ...sessionData,
    sessionToken: "refreshed-token",
    sessionTokenExpiresAt: new Date(Date.now() + 60_000),
  };
  const [firstRefresh, secondRefresh] = await Promise.all([
    memory.getOrCreatePaymentSessionForUser(refreshData),
    memory.getOrCreatePaymentSessionForUser({
      ...refreshData,
      sessionToken: "competing-token",
    }),
  ]);
  assert.equal(firstRefresh.session.sessionToken, "refreshed-token");
  assert.equal(secondRefresh.session.sessionToken, "refreshed-token");
});

test("new registrations acquire one durable payment session across devices", async () => {
  const memory = new MemStorage();
  const registrationSession = {
    userId: null,
    status: "pending",
    paymentStatus: "pending",
    registrationToken: "temporary-registration",
    sessionToken: "registration-session-token",
    sessionTokenExpiresAt: new Date(Date.now() + 60_000),
  } as const;
  const [firstClient, secondClient] = await Promise.all([
    memory.getOrCreatePaymentSessionForRegistration(registrationSession),
    memory.getOrCreatePaymentSessionForRegistration({
      ...registrationSession,
      sessionToken: "competing-registration-token",
    }),
  ]);
  assert.equal(firstClient.session.id, secondClient.session.id);
  assert.equal([firstClient.created, secondClient.created].filter(Boolean).length, 1);
  assert.equal(
    firstClient.session.sessionToken,
    secondClient.session.sessionToken,
  );

  await memory.updateTestSession(firstClient.session.id, {
    sessionToken: "expired-registration-token",
    sessionTokenExpiresAt: new Date(Date.now() - 1),
  });
  const refreshData = {
    ...registrationSession,
    sessionToken: "refreshed-registration-token",
    sessionTokenExpiresAt: new Date(Date.now() + 60_000),
  };
  const [firstRefresh, secondRefresh] = await Promise.all([
    memory.getOrCreatePaymentSessionForRegistration(refreshData),
    memory.getOrCreatePaymentSessionForRegistration({
      ...refreshData,
      sessionToken: "second-refresh-token",
    }),
  ]);
  assert.equal(firstRefresh.session.sessionToken, "refreshed-registration-token");
  assert.equal(secondRefresh.session.sessionToken, "refreshed-registration-token");
});

test("concurrent registration requests acquire one temporary registration token", async () => {
  const memory = new MemStorage();
  const registrationData = {
    firstName: "Nora",
    lastName: "Novino",
    email: "concurrent@example.com",
    phone: "0712345678",
    password: "hashed-password",
    token: "first-registration-token",
    expiresAt: new Date(Date.now() + 60_000),
  };
  const [firstClient, secondClient] = await Promise.all([
    memory.getOrCreateTempRegistration(registrationData),
    memory.getOrCreateTempRegistration({
      ...registrationData,
      token: "competing-registration-token",
    }),
  ]);
  assert.equal(firstClient.registration.token, secondClient.registration.token);
  assert.equal([firstClient.created, secondClient.created].filter(Boolean).length, 1);
});

test("expired registrations survive cleanup while their payment is unresolved", async () => {
  const memory = new MemStorage();
  const registration = await memory.createTempRegistration({
    token: "protected-expired-registration",
    firstName: "Nora",
    lastName: "Novino",
    email: "protected@example.com",
    phone: "0712345678",
    password: "hashed-password",
    expiresAt: new Date(Date.now() - 60_000),
  });
  const acquired = await memory.getOrCreatePaymentSessionForRegistration({
    userId: null,
    status: "pending",
    paymentStatus: "pending",
    registrationToken: registration.token,
    sessionToken: "protected-session-token",
    sessionTokenExpiresAt: new Date(Date.now() + 60_000),
  });
  const payment = await memory.createPayment({
    sessionId: acquired.session.id,
    paystackReference: "attempt-protected-expiry",
    amount: TEST_PRICE_KES,
    currency: "KES",
    provider: "palpluss",
    status: "pending",
  });

  await memory.deleteExpiredTempRegistrations();
  assert.equal(
    (await memory.getProtectedPaymentRegistrationByEmail(registration.email))?.token,
    registration.token,
  );
  assert.equal((await memory.getTempRegistration(registration.token))?.token, registration.token);

  await memory.updatePayment(payment.id, { status: "success" });
  await memory.updateTestSession(acquired.session.id, { paymentStatus: "completed" });
  await memory.deleteExpiredTempRegistrations();
  assert.equal((await memory.getTempRegistration(registration.token))?.token, registration.token);
  const duringFinalization = await memory.getOrCreatePaymentSessionForRegistration({
    userId: null,
    status: "pending",
    paymentStatus: "pending",
    registrationToken: registration.token,
    sessionToken: "competing-success-window-token",
    sessionTokenExpiresAt: new Date(Date.now() + 60_000),
  });
  assert.equal(duringFinalization.session.id, acquired.session.id);
  assert.equal(duringFinalization.created, false);

  await memory.updatePayment(payment.id, { status: "failed" });
  await memory.deleteExpiredTempRegistrations();
  assert.equal(await memory.getTempRegistration(registration.token), undefined);
});

test("completed sessions cannot receive a second certificate result", async () => {
  const memory = new MemStorage();
  const session = await memory.createTestSession({
    userId: "user-1",
    status: "in_progress",
    paymentStatus: "completed",
    startedAt: new Date(),
  });
  const first = await memory.completeTestSession(session.id, {
    status: "completed",
    passed: true,
    certificateId: "EP-FIRST",
  });
  const duplicate = await memory.completeTestSession(session.id, {
    status: "completed",
    passed: true,
    certificateId: "EP-SECOND",
  });
  assert.equal(first?.certificateId, "EP-FIRST");
  assert.equal(duplicate?.certificateId, "EP-FIRST");
});

test("assessment requirements remain complete and explicit", () => {
  assert.equal(SECTION_REQUIREMENTS.reading.questionIds.length, 15);
  assert.equal(SECTION_REQUIREMENTS.listening.questionIds.length, 10);
  assert.equal(SECTION_REQUIREMENTS.writing.minimumWords.writing_2, 250);
  assert.equal(SECTION_REQUIREMENTS.speaking.questionIds.length, 2);
});

test("server rejects forged speaking bytes instead of trusting claimed duration", async () => {
  await assert.rejects(
    () => validateAudioSubmission({
      audioData: `data:audio/webm;base64,${Buffer.alloc(30_000, 7).toString("base64")}`,
      size: 30_000,
      durationSeconds: 60,
      verifiedAudio: true,
    }),
    /could not be decoded/,
  );
});