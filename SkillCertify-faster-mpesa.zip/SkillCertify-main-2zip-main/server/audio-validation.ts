import crypto from "crypto";
import { execFile } from "child_process";
import { promisify } from "util";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import path from "path";

const execFileAsync = promisify(execFile);

export async function validateAudioSubmission(value: unknown): Promise<Record<string, unknown>> {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("A speaking recording is required");
  }
  const audioData = (value as Record<string, unknown>).audioData;
  if (typeof audioData !== "string") throw new Error("A speaking recording is required");
  const match = audioData.match(/^data:(audio\/[a-z0-9.+-]+)(?:;codecs=[^;,]+)?;base64,([a-z0-9+/]*={0,2})$/i);
  if (!match) throw new Error("The speaking recording format is invalid");

  const bytes = Buffer.from(match[2], "base64");
  if (bytes.byteLength < 20_000 || bytes.byteLength > 10_000_000) {
    throw new Error("The speaking recording is incomplete or too large");
  }

  const filePath = path.join(tmpdir(), `englishpro-${crypto.randomUUID()}.audio`);
  try {
    await writeFile(filePath, bytes);
    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "error",
      "-show_entries", "format=duration,format_name",
      "-of", "json",
      filePath,
    ], { timeout: 8_000, maxBuffer: 64_000 });
    const probe = JSON.parse(stdout);
    const durationSeconds = Number(probe?.format?.duration);
    const format = String(probe?.format?.format_name || "");
    if (!Number.isFinite(durationSeconds) || durationSeconds < 45 || durationSeconds > 180) {
      throw new Error("Each speaking response must contain 45 to 180 seconds of valid audio");
    }
    if (!/(webm|matroska|ogg|wav|mp4|mov)/i.test(format)) {
      throw new Error("The speaking recording uses an unsupported audio format");
    }
    return {
      audioData,
      size: bytes.byteLength,
      durationSeconds: Math.round(durationSeconds),
      verifiedAudio: true,
      format,
    };
  } catch (error) {
    if (error instanceof Error && /speaking recording|valid audio|unsupported/.test(error.message)) throw error;
    throw new Error("The speaking recording could not be decoded");
  } finally {
    await unlink(filePath).catch(() => undefined);
  }
}