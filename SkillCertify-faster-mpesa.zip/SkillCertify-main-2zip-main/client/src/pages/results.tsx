import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import CertificateGenerator from "@/components/certificate-generator";
import { formatUserName } from "@/utils/certificate";
import { AlertTriangle, CheckCircle, GraduationCap, RotateCcw } from "lucide-react";

type ResultDetails = {
  cefr?: string;
  proficiency?: string;
  feedback?: string[];
  passThreshold?: number;
  minimumSectionScore?: number;
};

export default function Results() {
  const { sessionId } = useParams();
  const [, setLocation] = useLocation();
  const { data: sessionData, isLoading, error } = useQuery<{ session: any }>({
    queryKey: ["/api/test-sessions", sessionId],
    enabled: Boolean(sessionId),
  });
  const { data: userData } = useQuery<{ user: any }>({
    queryKey: ["/api/users", sessionData?.session?.userId],
    enabled: Boolean(sessionData?.session?.userId),
  });

  if (isLoading) {
    return <div className="min-h-screen grid place-items-center"><p className="text-muted-foreground">Loading verified results…</p></div>;
  }

  const session = sessionData?.session;
  if (error || !session || session.status !== "completed") {
    return (
      <div className="min-h-screen grid place-items-center p-4">
        <Card className="max-w-md w-full"><CardContent className="p-8 text-center">
          <h1 className="text-xl font-semibold mb-3">Results not available</h1>
          <p className="text-muted-foreground mb-6">This assessment has not been submitted or your access link has expired.</p>
          <Button onClick={() => setLocation("/dashboard")}>Return to dashboard</Button>
        </CardContent></Card>
      </div>
    );
  }

  const details = (session.resultDetails || {}) as ResultDetails;
  const passed = session.passed === true;
  const hasCertificate = Boolean(session.certificateId);
  const scores = [
    ["Reading", session.readingScore || 0],
    ["Listening", session.listeningScore || 0],
    ["Writing", session.writingScore || 0],
    ["Speaking", session.speakingScore || 0],
  ] as const;
  const user = userData?.user;
  const completionDate = session.completedAt
    ? new Date(session.completedAt).toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })
    : "Not available";

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <nav className="bg-card border-b border-border">
        <div className="container-responsive h-16 flex items-center">
          <GraduationCap className="h-7 w-7 text-primary mr-3" />
          <span className="text-xl font-bold">EnglishPro Test</span>
        </div>
      </nav>

      <main className="container-responsive py-10">
        <header className="text-center max-w-2xl mx-auto mb-10">
          <div className={`w-16 h-16 rounded-full grid place-items-center mx-auto mb-4 ${passed ? "bg-green-100" : "bg-amber-100"}`}>
            {passed ? <CheckCircle className="h-9 w-9 text-green-700" /> : <AlertTriangle className="h-9 w-9 text-amber-700" />}
          </div>
          <h1 className="text-3xl font-bold mb-3">{passed ? "Assessment passed" : "Assessment complete"}</h1>
          <p className="text-muted-foreground">
            {passed
              ? "You met the overall and section-level standard. Your verified certificate is ready."
              : "Your certificate records your verified English performance. Review the breakdown below to identify areas for improvement."}
          </p>
        </header>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <Card><CardContent className="p-7">
            <h2 className="font-semibold text-lg mb-5">Verified assessment summary</h2>
            <div className="flex items-end gap-3 mb-5">
              <span className="text-5xl font-bold text-primary" data-testid="text-total-score">{session.totalScore}</span>
              <span className="text-muted-foreground mb-1">/ 100</span>
            </div>
            <dl className="grid grid-cols-2 gap-4 text-sm">
              <div><dt className="text-muted-foreground">CEFR level</dt><dd className="font-semibold text-lg">{details.cefr || "—"}</dd></div>
              <div><dt className="text-muted-foreground">Proficiency</dt><dd className="font-semibold text-lg">{details.proficiency || "—"}</dd></div>
              <div><dt className="text-muted-foreground">Completed</dt><dd className="font-medium">{completionDate}</dd></div>
              <div><dt className="text-muted-foreground">Standard</dt><dd className="font-medium">{details.passThreshold || 70}+ overall, {details.minimumSectionScore || 60}+ each skill</dd></div>
            </dl>
          </CardContent></Card>

          <Card><CardContent className="p-7">
            <h2 className="font-semibold text-lg mb-5">Skill breakdown</h2>
            <div className="space-y-5">
              {scores.map(([name, score]) => (
                <div key={name}>
                  <div className="flex justify-between mb-2"><span>{name}</span><strong>{score}/100</strong></div>
                  <Progress value={score} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent></Card>
        </div>

        {!passed && (
          <Card className="mb-8 border-amber-200"><CardContent className="p-7">
            <h2 className="font-semibold text-lg mb-3">Recommended next steps</h2>
            <ul className="list-disc ml-5 space-y-2 text-muted-foreground">
              {(details.feedback?.length ? details.feedback : ["Review each skill area below 60 before attempting the assessment again."]).map((item) => <li key={item}>{item}</li>)}
            </ul>
            <Button variant="outline" className="mt-6" onClick={() => setLocation("/register")}>
              <RotateCcw className="h-4 w-4 mr-2" /> Retake assessment
            </Button>
          </CardContent></Card>
        )}

        {hasCertificate && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-center mb-5">Verified certificate</h2>
            <CertificateGenerator data={{
              userName: user ? `${user.firstName} ${user.lastName}` : formatUserName(user?.email || "", ""),
              overallScore: session.totalScore || 0,
              sectionScores: {
                reading: session.readingScore || 0,
                listening: session.listeningScore || 0,
                writing: session.writingScore || 0,
                speaking: session.speakingScore || 0,
              },
              certificateId: session.certificateId,
              completionDate,
              testDuration: "60 minutes",
            }} />
          </section>
        )}

        <div className="text-center">
          <Button onClick={() => setLocation("/dashboard")}>Return to dashboard</Button>
        </div>
      </main>
    </div>
  );
}