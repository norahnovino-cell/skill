interface PalPlussConfig {
  sessionId: string;
  phone: string;
  tempToken?: string;
}

interface PalPlussResult {
  success: boolean;
  transactionId?: string;
  status?: string;
  retryable?: boolean;
  protected?: boolean;
  message?: string;
  user?: any;
  authToken?: string;
}

// Check every 3s (was 10s) so the success screen appears within a few seconds
// of the customer entering their PIN. Total wait is still ~5 minutes.
const FIRST_POLL_DELAY_MS = 3_000;
const POLL_INTERVAL_MS = 3_000;
const MAX_POLL_ATTEMPTS = 100;

function getHeaders(sessionId: string): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  const authToken = localStorage.getItem("auth_token");
  if (authToken) {
    headers["x-auth-token"] = authToken;
  }
  const sessionToken = localStorage.getItem(`session_token_${sessionId}`);
  if (sessionToken) {
    headers["x-session-token"] = sessionToken;
  }
  return headers;
}

async function readResponse(response: Response) {
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const error = new Error(
      data?.message || `Payment request failed with status ${response.status}`,
    ) as Error & Partial<PalPlussResult>;
    Object.assign(error, data || {});
    throw error;
  }
  return data;
}

export async function initializePalPluss(
  config: PalPlussConfig,
): Promise<PalPlussResult> {
  try {
    const response = await fetch("/api/payments/palpluss/stk", {
      method: "POST",
      headers: getHeaders(config.sessionId),
      body: JSON.stringify(config),
    });
    const data = await readResponse(response);

    if (!data.success || !data.transactionId) {
      return {
        success: false,
        message: data.message || "Unable to send the M-Pesa prompt",
      };
    }

    return pollPaymentStatus(
      data.transactionId,
      config.sessionId,
      config.tempToken,
    );
  } catch (error) {
    const paymentError = error as Error & Partial<PalPlussResult>;
    return {
      success: false,
      retryable: paymentError.retryable,
      protected: paymentError.protected,
      message: paymentError.message || "Unable to start M-Pesa payment",
    };
  }
}

async function pollPaymentStatus(
  transactionId: string,
  sessionId: string,
  tempToken?: string,
): Promise<PalPlussResult> {
  for (let attempt = 0; attempt < MAX_POLL_ATTEMPTS; attempt += 1) {
    await new Promise((resolve) =>
      setTimeout(resolve, attempt === 0 ? FIRST_POLL_DELAY_MS : POLL_INTERVAL_MS),
    );

    try {
      const response = await fetch("/api/payments/palpluss/status", {
        method: "POST",
        headers: getHeaders(sessionId),
        body: JSON.stringify({ transactionId, tempToken }),
      });
      const data = await readResponse(response);

      if (data.success) {
        return { ...data, transactionId };
      }

      if (data.status !== "pending") {
        return {
          success: false,
          transactionId,
          status: data.status,
          retryable: data.retryable,
          protected: data.protected,
          message: data.message || "M-Pesa payment was not completed",
        };
      }
    } catch (error) {
      if (attempt === MAX_POLL_ATTEMPTS - 1) {
        const paymentError = error as Error & Partial<PalPlussResult>;
        return {
          success: false,
          transactionId,
          status: "pending",
          retryable: false,
          protected: true,
          message: paymentError.message || "Unable to verify M-Pesa payment",
        };
      }
    }
  }

  return {
    success: false,
    transactionId,
    status: "pending",
    retryable: false,
    protected: true,
    message:
      "Payment confirmation timed out. Check your M-Pesa messages before trying again.",
  };
}