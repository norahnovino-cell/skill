# Verified assessment release check

## Automated and local checks

- `npm test` covers registration validation, incomplete submissions, strict scoring, completion certificate issuance policy, and exact PalPluss amount/currency/status checks.
- `npm run check` validates TypeScript.
- `npm run build` validates the production bundle.
- `npm run db:push` applies the additive PostgreSQL schema used for sessions, answers, payments, results, and certificate metadata.

## Non-charging verification

Use mocked PalPluss responses in automated/local testing. A successful transaction must report `SUCCESS`, exactly `1000`, and `KES`; no fallback payment provider or development auto-success path is active.

## One manual check after publishing

With explicit approval from the person whose M-Pesa number will be used, initiate one KES 1,000 STK Push on the published HTTPS app. Confirm that only one prompt arrives, the test stays locked before confirmation, and access appears only after PalPluss returns the exact successful transaction. This is the only real-money step and must not be run automatically.